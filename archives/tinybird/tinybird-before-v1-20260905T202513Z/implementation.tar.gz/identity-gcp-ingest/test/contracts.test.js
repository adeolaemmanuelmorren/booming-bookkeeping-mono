import assert from "node:assert/strict";
import test from "node:test";
import {
  ContractError,
  outputRowsHash,
  parseIdentityRowChunk,
} from "../src/contracts.js";

test("row chunk hash covers the exact row identities", () => {
  const row = identityRow();
  const chunk = chunkBody(row);
  const parsed = parseIdentityRowChunk(chunk);
  assert.equal(parsed.chunkHash, outputRowsHash([row]));
});

test("rows from another batch are rejected", () => {
  const row = identityRow();
  row.batch_id = "other_batch";

  assert.throws(
    () => parseIdentityRowChunk(chunkBody(row)),
    ContractError,
  );
});

test("row chunks are bounded", () => {
  const row = identityRow();
  const rows = Array.from({ length: 201 }, () => ({ ...row }));
  const chunk = chunkBody(row);
  chunk.rows = rows;
  chunk.rowCount = rows.length;
  chunk.chunkHash = outputRowsHash(rows);

  assert.throws(
    () => parseIdentityRowChunk(chunk),
    /rows must contain at most 200 items/,
  );
});

function chunkBody(row) {
  return {
    schemaVersion: 1,
    event: "identity.batch.rows",
    manifest: {
      tenantId: "boom",
      batchVersion: 42,
      batchId: "batch_42",
      inputEventCount: 1,
      inputHash: "b".repeat(64),
      outputRowCount: 1,
      outputHash: "a".repeat(64),
      checkpointIngestedAt: "2026-09-04 00:00:00",
      checkpointEventId: "event_1",
    },
    chunkIndex: 0,
    chunkCount: 1,
    rowCount: 1,
    chunkHash: outputRowsHash([row]),
    rows: [row],
  };
}

function identityRow() {
  return {
    tenant_id: "boom",
    batch_version: 42,
    batch_id: "batch_42",
    state_kind: "mapping",
    lookup_key: "email:test@example.com",
    sub_key: "",
    row_hash: "c".repeat(64),
  };
}
