import assert from "node:assert/strict";
import { Readable } from "node:stream";
import test from "node:test";
import { createRequestHandler } from "../src/app.js";
import { outputRowsHash } from "../src/contracts.js";
import {
  IdentityBatchConflictError,
  IncompleteIdentityBatchError,
} from "../src/bigquery-store.js";

test("health check does not require the transport secret", async () => {
  const response = await handler().handle(request("GET", "/healthz"));
  assert.equal(response.status, 200);
});

test("row chunks require a valid bearer token", async () => {
  const response = await handler().handle(request(
    "POST",
    "/v1/identity-batches/chunks",
    chunkBody(),
  ));
  assert.equal(response.status, 401);
});

test("valid row chunks are passed to the store", async () => {
  const service = handler();
  const response = await service.handle(request(
    "POST",
    "/v1/identity-batches/chunks",
    chunkBody(),
    "Bearer test-secret",
  ));

  assert.equal(response.status, 200);
  assert.equal(service.calls.stageChunk.length, 1);
  assert.equal(service.calls.stageChunk[0].rows.length, 1);
});

test("activation is passed to the store", async () => {
  const service = handler();
  const response = await service.handle(request(
    "POST",
    "/v1/identity-batches/activate",
    activationBody(),
    "Bearer test-secret",
  ));

  assert.equal(response.status, 200);
  assert.equal(service.calls.activateBatch.length, 1);
});

test("an incomplete streamed batch asks the Worker to retry", async () => {
  const service = handler({
    activationError: new IncompleteIdentityBatchError("Rows are still arriving."),
  });
  const response = await service.handle(request(
    "POST",
    "/v1/identity-batches/activate",
    activationBody(),
    "Bearer test-secret",
  ));

  assert.equal(response.status, 503);
});

test("a conflicting activation is terminal", async () => {
  const service = handler({
    activationError: new IdentityBatchConflictError("Batch contents conflict."),
  });
  const response = await service.handle(request(
    "POST",
    "/v1/identity-batches/activate",
    activationBody(),
    "Bearer test-secret",
  ));

  assert.equal(response.status, 409);
});

function handler({ activationError = null } = {}) {
  const calls = { stageChunk: [], activateBatch: [] };
  const store = {
    async stageChunk(chunk) {
      calls.stageChunk.push(chunk);
      return { status: "staged" };
    },
    async activateBatch(activation) {
      calls.activateBatch.push(activation);
      if (activationError) throw activationError;
      return { status: "activated" };
    },
  };

  return {
    calls,
    handle: createRequestHandler({ store, expectedToken: "test-secret" }),
  };
}

function request(method, path, body, authorization) {
  const value = body === undefined ? "" : JSON.stringify(body);
  const stream = Readable.from([value]);
  stream.method = method;
  stream.url = path;
  stream.headers = { authorization };
  return stream;
}

function chunkBody() {
  const row = identityRow();
  return {
    schemaVersion: 1,
    event: "identity.batch.rows",
    manifest: manifest(),
    chunkIndex: 0,
    chunkCount: 1,
    rowCount: 1,
    chunkHash: outputRowsHash([row]),
    rows: [row],
  };
}

function activationBody() {
  return {
    schemaVersion: 1,
    event: "identity.batch.activated",
    manifest: manifest(),
    activatedAt: "2026-09-04T00:01:00.000Z",
  };
}

function manifest() {
  return {
    tenantId: "boom",
    batchVersion: 42,
    batchId: "batch_42",
    inputEventCount: 1,
    inputHash: "b".repeat(64),
    outputRowCount: 1,
    outputHash: "a".repeat(64),
    checkpointIngestedAt: "2026-09-04 00:00:00",
    checkpointEventId: "event_1",
  };
}

function identityRow() {
  return {
    tenant_id: "boom",
    batch_version: 42,
    batch_id: "batch_42",
    state_kind: "mapping",
    lookup_key: "email:test@example.com",
    sub_key: "",
    row_hash: "c".repeat(64),
  };
}
