import assert from "node:assert/strict";
import test from "node:test";
import { createIdentityBigQueryStore } from "../src/bigquery-store.js";

test("staging uses deterministic raw inserts", async () => {
  const fake = fakeBigQuery();
  const store = createIdentityBigQueryStore({
    projectId: "project",
    datasetId: "dataset",
    location: "US",
    bigQuery: fake.client,
  });

  await store.stageChunk(chunk());
  await store.stageChunk(chunk());

  assert.equal(fake.inserts.length, 2);
  assert.equal(fake.inserts[0].rows[0].insertId, fake.inserts[1].rows[0].insertId);
  assert.equal(fake.inserts[0].options.raw, true);
});

test("activation validates staged rows before merging a receipt", async () => {
  const fake = fakeBigQuery([
    [{
      actual_output_row_count: 1,
      actual_output_hash: "a".repeat(64),
    }],
    [],
  ]);
  const store = createIdentityBigQueryStore({
    projectId: "project",
    datasetId: "dataset",
    location: "US",
    bigQuery: fake.client,
  });

  const result = await store.activateBatch(activation());

  assert.equal(result.status, "activated");
  assert.equal(fake.queries.length, 2);
  assert.match(fake.queries[1].query, /MERGE `project\.dataset\.identity_worker_batch_receipts`/);
});

function fakeBigQuery(queryResults = []) {
  const inserts = [];
  const queries = [];
  const client = {
    dataset() {
      return {
        table() {
          return {
            async insert(rows, options) {
              inserts.push({ rows, options });
            },
          };
        },
      };
    },
    async query(options) {
      queries.push(options);
      return [queryResults.shift() ?? []];
    },
  };
  return { client, inserts, queries };
}

function chunk() {
  const manifest = batchManifest();
  return {
    manifest,
    chunkIndex: 0,
    chunkCount: 1,
    chunkHash: "d".repeat(64),
    rows: [{
      tenant_id: manifest.tenantId,
      batch_version: manifest.batchVersion,
      batch_id: manifest.batchId,
      state_kind: "mapping",
      lookup_key: "email:test@example.com",
      sub_key: "",
      row_hash: "c".repeat(64),
    }],
  };
}

function activation() {
  return {
    manifest: batchManifest(),
    activatedAt: "2026-09-04T00:01:00.000Z",
  };
}

function batchManifest() {
  return {
    tenantId: "boom",
    batchVersion: 42,
    batchId: "batch_42",
    inputEventCount: 1,
    inputHash: "b".repeat(64),
    outputRowCount: 1,
    outputHash: "a".repeat(64),
    checkpointIngestedAt: "2026-09-04 00:00:00",
    checkpointEventId: "event_1",
  };
}
