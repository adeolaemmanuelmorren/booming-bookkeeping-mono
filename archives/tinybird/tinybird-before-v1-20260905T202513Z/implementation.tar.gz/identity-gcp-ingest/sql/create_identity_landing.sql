CREATE TABLE IF NOT EXISTS `able-folio-499722.dataform_realtime.identity_worker_delta_staging` (
  tenant_id STRING NOT NULL,
  batch_version INT64 NOT NULL,
  batch_id STRING NOT NULL,
  output_key STRING NOT NULL,
  state_kind STRING NOT NULL,
  lookup_key STRING NOT NULL,
  sub_key STRING NOT NULL,
  row_hash STRING NOT NULL,
  payload_json STRING NOT NULL,
  chunk_index INT64 NOT NULL,
  chunk_count INT64 NOT NULL,
  chunk_hash STRING NOT NULL,
  received_at TIMESTAMP NOT NULL
)
PARTITION BY DATE(received_at)
CLUSTER BY tenant_id, batch_version, batch_id, state_kind;

CREATE TABLE IF NOT EXISTS `able-folio-499722.dataform_realtime.identity_worker_batch_receipts` (
  tenant_id STRING NOT NULL,
  batch_version INT64 NOT NULL,
  batch_id STRING NOT NULL,
  input_event_count INT64 NOT NULL,
  input_hash STRING NOT NULL,
  output_row_count INT64 NOT NULL,
  output_hash STRING NOT NULL,
  checkpoint_ingested_at STRING NOT NULL,
  checkpoint_event_id STRING NOT NULL,
  activated_at TIMESTAMP NOT NULL,
  received_at TIMESTAMP NOT NULL
)
PARTITION BY DATE(activated_at)
CLUSTER BY tenant_id, batch_version, batch_id;

CREATE OR REPLACE VIEW `able-folio-499722.dataform_realtime.identity_worker_activated_deltas` AS
SELECT staging.*
FROM `able-folio-499722.dataform_realtime.identity_worker_delta_staging` AS staging
INNER JOIN `able-folio-499722.dataform_realtime.identity_worker_batch_receipts` AS receipt
  USING (tenant_id, batch_version, batch_id)
QUALIFY ROW_NUMBER() OVER (
  PARTITION BY tenant_id, batch_version, batch_id, output_key
  ORDER BY staging.received_at
) = 1;
