import { timingSafeEqual } from "node:crypto";

export function hasValidBearerToken(headerValue, expectedToken) {
  if (!expectedToken) return false;
  if (typeof headerValue !== "string") return false;
  if (!headerValue.startsWith("Bearer ")) return false;

  const provided = Buffer.from(headerValue.slice("Bearer ".length));
  const expected = Buffer.from(expectedToken);
  if (provided.length !== expected.length) return false;

  return timingSafeEqual(provided, expected);
}
