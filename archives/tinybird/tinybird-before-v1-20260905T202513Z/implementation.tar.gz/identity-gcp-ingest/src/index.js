import { createServer } from "node:http";
import { createRequestHandler } from "./app.js";
import { createIdentityBigQueryStore } from "./bigquery-store.js";

const port = Number(process.env.PORT ?? 8080);
const projectId = process.env.BIGQUERY_PROJECT_ID ?? "able-folio-499722";
const datasetId = process.env.BIGQUERY_DATASET_ID ?? "dataform_realtime";
const location = process.env.BIGQUERY_LOCATION ?? "US";
const expectedToken = process.env.IDENTITY_INGEST_SECRET;

if (!expectedToken) throw new Error("IDENTITY_INGEST_SECRET is required.");

const store = createIdentityBigQueryStore({ projectId, datasetId, location });
const handleRequest = createRequestHandler({ store, expectedToken });

const server = createServer(async (request, response) => {
  const result = await handleRequest(request);
  response.writeHead(result.status, result.headers);
  response.end(result.body);
});

server.listen(port, "0.0.0.0", () => {
  console.log(`Identity GCP ingest listening on port ${port}.`);
});
