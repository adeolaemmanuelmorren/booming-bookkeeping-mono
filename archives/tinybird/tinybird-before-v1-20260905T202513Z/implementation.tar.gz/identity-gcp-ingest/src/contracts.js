import { createHash } from "node:crypto";

const HASH_PATTERN = /^[0-9a-f]{64}$/;
const MAX_ROWS_PER_CHUNK = 200;

export function parseIdentityRowChunk(value) {
  const body = record(value, "request body");
  if (body.schemaVersion !== 1) throw new ContractError("schemaVersion must be 1.");
  if (body.event !== "identity.batch.rows") {
    throw new ContractError("event must be identity.batch.rows.");
  }

  const manifest = parseManifest(body.manifest);
  const chunkIndex = nonNegativeInteger(body.chunkIndex, "chunkIndex");
  const chunkCount = positiveInteger(body.chunkCount, "chunkCount");
  if (chunkIndex >= chunkCount) {
    throw new ContractError("chunkIndex must be smaller than chunkCount.");
  }

  if (!Array.isArray(body.rows) || body.rows.length === 0) {
    throw new ContractError("rows must be a non-empty array.");
  }
  if (body.rows.length > MAX_ROWS_PER_CHUNK) {
    throw new ContractError(`rows must contain at most ${MAX_ROWS_PER_CHUNK} items.`);
  }
  const rows = body.rows.map((row, index) => parseIdentityRow(
    row,
    manifest,
    `rows[${index}]`,
  ));
  const rowCount = positiveInteger(body.rowCount, "rowCount");
  if (rowCount !== rows.length) {
    throw new ContractError("rowCount does not match rows.length.");
  }

  const chunkHash = hash(body.chunkHash, "chunkHash");
  if (chunkHash !== outputRowsHash(rows)) {
    throw new ContractError("chunkHash does not match the chunk rows.");
  }

  return {
    schemaVersion: 1,
    event: body.event,
    manifest,
    chunkIndex,
    chunkCount,
    rowCount,
    chunkHash,
    rows,
  };
}

export function parseIdentityActivation(value) {
  const body = record(value, "request body");
  if (body.schemaVersion !== 1) throw new ContractError("schemaVersion must be 1.");
  if (body.event !== "identity.batch.activated") {
    throw new ContractError("event must be identity.batch.activated.");
  }

  const activatedAt = text(body.activatedAt, "activatedAt");
  if (Number.isNaN(Date.parse(activatedAt))) {
    throw new ContractError("activatedAt must be an ISO timestamp.");
  }

  return {
    schemaVersion: 1,
    event: body.event,
    manifest: parseManifest(body.manifest),
    activatedAt,
  };
}

export class ContractError extends Error {}

function parseManifest(value) {
  const manifest = record(value, "manifest");
  return {
    tenantId: safeKey(manifest.tenantId, "manifest.tenantId"),
    batchVersion: positiveInteger(manifest.batchVersion, "manifest.batchVersion"),
    batchId: safeKey(manifest.batchId, "manifest.batchId", 200),
    inputEventCount: nonNegativeInteger(
      manifest.inputEventCount,
      "manifest.inputEventCount",
    ),
    inputHash: hash(manifest.inputHash, "manifest.inputHash"),
    outputRowCount: nonNegativeInteger(
      manifest.outputRowCount,
      "manifest.outputRowCount",
    ),
    outputHash: hash(manifest.outputHash, "manifest.outputHash"),
    checkpointIngestedAt: text(
      manifest.checkpointIngestedAt,
      "manifest.checkpointIngestedAt",
    ),
    checkpointEventId: text(
      manifest.checkpointEventId,
      "manifest.checkpointEventId",
    ),
  };
}

function parseIdentityRow(value, manifest, name) {
  const row = record(value, name);
  if (row.tenant_id !== manifest.tenantId) {
    throw new ContractError(`${name}.tenant_id does not match the manifest.`);
  }
  if (row.batch_version !== manifest.batchVersion) {
    throw new ContractError(`${name}.batch_version does not match the manifest.`);
  }
  if (row.batch_id !== manifest.batchId) {
    throw new ContractError(`${name}.batch_id does not match the manifest.`);
  }

  text(row.state_kind, `${name}.state_kind`);
  text(row.lookup_key, `${name}.lookup_key`, true);
  text(row.sub_key, `${name}.sub_key`, true);
  hash(row.row_hash, `${name}.row_hash`);
  return row;
}

export function outputRowKey(row) {
  return `${row.state_kind}:${row.lookup_key}:${row.sub_key}:${row.row_hash}`;
}

export function outputRowsHash(rows) {
  const value = rows.map(outputRowKey).sort().join("|");
  return createHash("sha256").update(value).digest("hex");
}

function record(value, name) {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    throw new ContractError(`${name} must be an object.`);
  }
  return value;
}

function text(value, name, allowEmpty = false) {
  if (typeof value !== "string") throw new ContractError(`${name} must be a string.`);
  if (!allowEmpty && !value) throw new ContractError(`${name} must not be empty.`);
  return value;
}

function safeKey(value, name, maximumLength = 100) {
  const parsed = text(value, name);
  if (parsed.length > maximumLength) {
    throw new ContractError(`${name} is too long.`);
  }
  if (!/^[A-Za-z0-9._:-]+$/.test(parsed)) {
    throw new ContractError(`${name} contains unsupported characters.`);
  }
  return parsed;
}

function hash(value, name) {
  const parsed = text(value, name);
  if (!HASH_PATTERN.test(parsed)) {
    throw new ContractError(`${name} must be a lowercase SHA-256 hash.`);
  }
  return parsed;
}

function positiveInteger(value, name) {
  if (!Number.isSafeInteger(value) || value < 1) {
    throw new ContractError(`${name} must be a positive integer.`);
  }
  return value;
}

function nonNegativeInteger(value, name) {
  if (!Number.isSafeInteger(value) || value < 0) {
    throw new ContractError(`${name} must be a non-negative integer.`);
  }
  return value;
}
