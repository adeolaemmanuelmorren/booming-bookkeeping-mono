import { hasValidBearerToken } from "./auth.js";
import {
  ContractError,
  parseIdentityActivation,
  parseIdentityRowChunk,
} from "./contracts.js";
import {
  IdentityBatchConflictError,
  IncompleteIdentityBatchError,
} from "./bigquery-store.js";

const JSON_HEADERS = {
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "no-store",
  "X-Content-Type-Options": "nosniff",
};
const MAX_BODY_BYTES = 16 * 1024 * 1024;

export function createRequestHandler({ store, expectedToken }) {
  return async function handleRequest(request) {
    const url = new URL(request.url ?? "/", "http://localhost");

    if (request.method === "GET" && url.pathname === "/healthz") {
      return json({ ok: true });
    }

    const isChunk = request.method === "POST"
      && url.pathname === "/v1/identity-batches/chunks";
    const isActivation = request.method === "POST"
      && url.pathname === "/v1/identity-batches/activate";
    if (!isChunk && !isActivation) return json({ error: "Not found." }, 404);

    if (!hasValidBearerToken(request.headers.authorization, expectedToken)) {
      return json({ error: "Unauthorized." }, 401);
    }

    try {
      const body = await readJsonBody(request, MAX_BODY_BYTES);
      const result = isChunk
        ? await store.stageChunk(parseIdentityRowChunk(body))
        : await store.activateBatch(parseIdentityActivation(body));
      return json(result);
    } catch (error) {
      if (error instanceof ContractError || error instanceof SyntaxError) {
        return json({ error: error.message }, 400);
      }
      if (error instanceof IdentityBatchConflictError) {
        return json({ error: error.message }, 409);
      }
      if (error instanceof IncompleteIdentityBatchError) {
        return json({ error: error.message }, 503);
      }
      if (error instanceof RequestTooLargeError) {
        return json({ error: error.message }, 413);
      }

      console.error("Unable to ingest identity batch.", error);
      return json({ error: "Identity ingestion is temporarily unavailable." }, 503);
    }
  };
}

class RequestTooLargeError extends Error {}

async function readJsonBody(request, maximumBytes) {
  let bytes = 0;
  const chunks = [];

  for await (const chunk of request) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    bytes += buffer.length;
    if (bytes > maximumBytes) {
      throw new RequestTooLargeError("Request body is too large.");
    }
    chunks.push(buffer);
  }

  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}

function json(body, status = 200) {
  return {
    status,
    headers: JSON_HEADERS,
    body: JSON.stringify(body),
  };
}
