import { createHash } from "node:crypto";
import { BigQuery } from "@google-cloud/bigquery";
import { outputRowKey } from "./contracts.js";

export class IncompleteIdentityBatchError extends Error {}
export class IdentityBatchConflictError extends Error {}

export function createIdentityBigQueryStore({
  projectId,
  datasetId,
  location,
  stagingTableId = "identity_worker_delta_staging",
  receiptTableId = "identity_worker_batch_receipts",
  bigQuery = new BigQuery({ projectId }),
}) {
  const stagingTable = bigQuery.dataset(datasetId).table(stagingTableId);
  const stagingTableName = tableName(projectId, datasetId, stagingTableId);
  const receiptTableName = tableName(projectId, datasetId, receiptTableId);

  async function stageChunk(chunk) {
    const receivedAt = new Date().toISOString();
    const rows = chunk.rows.map((row) => {
      const outputKey = outputRowKey(row);
      return {
        insertId: insertId(chunk.manifest, outputKey),
        json: {
          tenant_id: chunk.manifest.tenantId,
          batch_version: chunk.manifest.batchVersion,
          batch_id: chunk.manifest.batchId,
          output_key: outputKey,
          state_kind: row.state_kind,
          lookup_key: row.lookup_key,
          sub_key: row.sub_key,
          row_hash: row.row_hash,
          payload_json: JSON.stringify(row),
          chunk_index: chunk.chunkIndex,
          chunk_count: chunk.chunkCount,
          chunk_hash: chunk.chunkHash,
          received_at: receivedAt,
        },
      };
    });

    await stagingTable.insert(rows, {
      raw: true,
      ignoreUnknownValues: false,
      skipInvalidRows: false,
    });

    return {
      status: "staged",
      rowCount: rows.length,
      chunkIndex: chunk.chunkIndex,
    };
  }

  async function activateBatch(activation) {
    const manifest = activation.manifest;
    const [summaryRows] = await bigQuery.query({
      query: stagedBatchSummarySql(stagingTableName),
      location,
      params: batchParameters(manifest),
    });
    const summary = summaryRows[0] ?? {};
    const actualRowCount = Number(summary.actual_output_row_count ?? 0);
    const actualOutputHash = String(summary.actual_output_hash ?? "");

    if (
      actualRowCount !== manifest.outputRowCount
      || actualOutputHash !== manifest.outputHash
    ) {
      throw new IncompleteIdentityBatchError(
        `Staged batch has ${actualRowCount} of ${manifest.outputRowCount} rows.`,
      );
    }

    try {
      await bigQuery.query({
        query: mergeReceiptSql(receiptTableName),
        location,
        params: {
          ...batchParameters(manifest),
          input_event_count: manifest.inputEventCount,
          input_hash: manifest.inputHash,
          output_row_count: manifest.outputRowCount,
          output_hash: manifest.outputHash,
          checkpoint_ingested_at: manifest.checkpointIngestedAt,
          checkpoint_event_id: manifest.checkpointEventId,
          activated_at: activation.activatedAt,
        },
      });
    } catch (error) {
      if (String(error).includes("IDENTITY_BATCH_CONFLICT")) {
        throw new IdentityBatchConflictError("An existing receipt has different batch contents.");
      }
      throw error;
    }

    return {
      status: "activated",
      rowCount: actualRowCount,
      outputHash: actualOutputHash,
    };
  }

  return { stageChunk, activateBatch };
}

export function stagedBatchSummarySql(stagingTableName) {
  return `
    WITH distinct_rows AS (
      SELECT DISTINCT output_key
      FROM ${stagingTableName}
      WHERE tenant_id = @tenant_id
        AND batch_version = @batch_version
        AND batch_id = @batch_id
    )
    SELECT
      COUNT(*) AS actual_output_row_count,
      LOWER(TO_HEX(SHA256(COALESCE(
        STRING_AGG(output_key, '|' ORDER BY output_key),
        ''
      )))) AS actual_output_hash
    FROM distinct_rows
  `;
}

export function mergeReceiptSql(receiptTableName) {
  return `
    ASSERT NOT EXISTS (
      SELECT 1
      FROM ${receiptTableName}
      WHERE tenant_id = @tenant_id
        AND batch_version = @batch_version
        AND batch_id = @batch_id
        AND (output_row_count != @output_row_count OR output_hash != @output_hash)
    ) AS 'IDENTITY_BATCH_CONFLICT';

    MERGE ${receiptTableName} AS target
    USING (
      SELECT
        @tenant_id AS tenant_id,
        @batch_version AS batch_version,
        @batch_id AS batch_id,
        @input_event_count AS input_event_count,
        @input_hash AS input_hash,
        @output_row_count AS output_row_count,
        @output_hash AS output_hash,
        @checkpoint_ingested_at AS checkpoint_ingested_at,
        @checkpoint_event_id AS checkpoint_event_id,
        TIMESTAMP(@activated_at) AS activated_at
    ) AS source
    ON target.tenant_id = source.tenant_id
      AND target.batch_version = source.batch_version
      AND target.batch_id = source.batch_id
    WHEN NOT MATCHED THEN
      INSERT (
        tenant_id,
        batch_version,
        batch_id,
        input_event_count,
        input_hash,
        output_row_count,
        output_hash,
        checkpoint_ingested_at,
        checkpoint_event_id,
        activated_at,
        received_at
      )
      VALUES (
        source.tenant_id,
        source.batch_version,
        source.batch_id,
        source.input_event_count,
        source.input_hash,
        source.output_row_count,
        source.output_hash,
        source.checkpoint_ingested_at,
        source.checkpoint_event_id,
        source.activated_at,
        CURRENT_TIMESTAMP()
      )
  `;
}

function batchParameters(manifest) {
  return {
    tenant_id: manifest.tenantId,
    batch_version: manifest.batchVersion,
    batch_id: manifest.batchId,
  };
}

function insertId(manifest, outputKey) {
  const value = [
    manifest.tenantId,
    manifest.batchVersion,
    manifest.batchId,
    outputKey,
  ].join("\u0000");
  return createHash("sha256").update(value).digest("hex");
}

function tableName(projectId, datasetId, tableId) {
  for (const [name, value] of Object.entries({ projectId, datasetId, tableId })) {
    if (!/^[A-Za-z0-9_-]+$/.test(value)) {
      throw new Error(`${name} contains unsupported characters.`);
    }
  }
  return `\`${projectId}.${datasetId}.${tableId}\``;
}
