# Identity GCP ingest

This private-purpose Cloud Run service receives resolved identity delta chunks from the Cloudflare identity Worker and lands them in BigQuery.

Rows are staged before Tinybird activation. The service writes a batch receipt only after the Worker confirms activation and the staged distinct row count and hash match the identity manifest. Downstream queries should read `identity_worker_activated_deltas`, never the staging table directly.

## Routes

- `GET /healthz`
- `POST /v1/identity-batches/chunks`
- `POST /v1/identity-batches/activate`

Both POST routes require `Authorization: Bearer <IDENTITY_INGEST_SECRET>`.

## Setup

1. Run `sql/create_identity_landing.sql` in BigQuery.
2. Deploy this folder to Cloud Run with a dedicated service account. The current Worker authentication uses a shared application secret, so Cloud Run must permit network-level invocation while the application rejects unauthenticated POST requests.
3. Grant that service account BigQuery Data Editor on `dataform_realtime` and BigQuery Job User on the project.
4. Set `IDENTITY_INGEST_SECRET` on Cloud Run.
5. Set the same value as the Worker's `IDENTITY_GCP_INGEST_TOKEN` secret.
6. Set the Worker's `IDENTITY_GCP_INGEST_URL` to the Cloud Run service URL.

The service uses Application Default Credentials from its Cloud Run service account. Do not place a GCP service-account key in this service.

Enable the Worker settings only while no identity batch is already prepared or activating. This first release stages new batches; it does not reconstruct a partly completed historical batch.
