import { describe, expect, it, vi } from "vitest";
import {
  forwardIdentityActivation,
  forwardIdentityRows,
  identityGcpIngestConfig,
} from "../src/identity-gcp-forwarding";
import type { IdentityEngineResult, IdentityJournalRow } from "../src/identity-engine";
import type { IdentityCompactionManifest } from "../src/tinybird-api";

describe("identity GCP forwarding", () => {
  it("stays disabled until both settings are configured", () => {
    expect(identityGcpIngestConfig({})).toBeNull();
    expect(() => identityGcpIngestConfig({
      IDENTITY_GCP_INGEST_URL: "https://identity.example.com",
    })).toThrow("IDENTITY_GCP_INGEST_TOKEN is required");
  });

  it("sends bounded row chunks with deterministic hashes", async () => {
    const requests: { url: string; init?: RequestInit }[] = [];
    const fetcher: typeof fetch = vi.fn(async (input, init) => {
      requests.push({ url: String(input), init });
      return Response.json({ ok: true });
    });
    const engine = engineResult(401);

    await forwardIdentityRows(engine, config(), fetcher);

    expect(requests).toHaveLength(3);
    const first = JSON.parse(String(requests[0].init?.body));
    const final = JSON.parse(String(requests[2].init?.body));
    expect(first.chunkIndex).toBe(0);
    expect(first.chunkCount).toBe(3);
    expect(first.rows).toHaveLength(200);
    expect(first.chunkHash).toMatch(/^[0-9a-f]{64}$/);
    expect(final.chunkIndex).toBe(2);
    expect(final.rows).toHaveLength(1);
  });

  it("sends the activation receipt after Tinybird activation", async () => {
    let body: Record<string, unknown> | null = null;
    const fetcher: typeof fetch = vi.fn(async (_input, init) => {
      body = JSON.parse(String(init?.body));
      return Response.json({ ok: true });
    });

    await forwardIdentityActivation(compactionManifest(), config(), fetcher);

    expect(body).toMatchObject({
      schemaVersion: 1,
      event: "identity.batch.activated",
      manifest: {
        tenantId: "boom",
        batchVersion: 42,
        batchId: "batch_42",
        outputRowCount: 1,
      },
    });
  });

  it("keeps response status for retry classification", async () => {
    const fetcher: typeof fetch = vi.fn(async () => new Response("busy", { status: 503 }));

    await expect(
      forwardIdentityActivation(compactionManifest(), config(), fetcher),
    ).rejects.toMatchObject({ status: 503 });
  });
});

function config() {
  return {
    baseUrl: "https://identity.example.com",
    token: "test-token",
    timeoutMs: 1_000,
  };
}

function engineResult(rowCount: number): IdentityEngineResult {
  const rows = Array.from({ length: rowCount }, (_, index) => journalRow(index));
  const manifest = journalRow(rowCount);
  manifest.state_kind = "batch_manifest";
  manifest.input_event_count = rowCount;
  manifest.output_row_count = rowCount;
  manifest.output_hash = "a".repeat(64);
  manifest.input_hash = "b".repeat(64);

  return {
    inputHash: manifest.input_hash,
    changedFacts: [],
    rows,
    manifest,
    outputHash: manifest.output_hash,
  };
}

function journalRow(index: number): IdentityJournalRow {
  return {
    tenant_id: "boom",
    state_kind: "mapping",
    state_key: `mapping:${index}`,
    lookup_key: `email:user${index}@example.com`,
    sub_key: "",
    batch_version: 42,
    batch_id: "batch_42",
    committed_at: "2026-09-04T00:00:00.000Z",
    is_deleted: 0,
    row_hash: index.toString(16).padStart(64, "0"),
    identifier_type: "email",
    identifier_value: `user${index}@example.com`,
    identifier_key: `email:user${index}@example.com`,
    profile_id: "profile",
    profile_key: "profile@example.com",
    winner_identifier_key: "email:profile@example.com",
    member_identifier_keys: [],
    anonymous_ids: [],
    user_ids: [],
    emails: [],
    phones: [],
    historical_profile_ids: [],
    first_name: "",
    last_name: "",
    first_seen_at: "2026-09-04T00:00:00.000Z",
    last_seen_at: "2026-09-04T00:00:00.000Z",
    fact_kind: "",
    fact_key: "",
    source_fact_version: 0,
    fact_deleted: 0,
    fact_observed_at: "1970-01-01T00:00:00.000Z",
    fact_payload_hash: "0".repeat(64),
    fact_payload: "",
    evidence_keys: [],
    producer_id: "identity_compactor",
    checkpoint_sequence: 0,
    checkpoint_ingested_at: "2026-09-04 00:00:00",
    checkpoint_event_id: "event",
    prior_profile_ids: [],
    dirty_profile_ids: [],
    input_event_count: 0,
    input_hash: "0".repeat(64),
    output_row_count: 0,
    output_hash: "0".repeat(64),
  };
}

function compactionManifest(): IdentityCompactionManifest {
  return {
    tenantId: "boom",
    batchVersion: 42,
    batchId: "batch_42",
    inputEventCount: 1,
    inputHash: "b".repeat(64),
    checkpointIngestedAt: "2026-09-04 00:00:00",
    checkpointEventId: "event",
    expectedOutputRowCount: 1,
    expectedOutputHash: "a".repeat(64),
    actualOutputRowCount: 1,
    actualOutputHash: "a".repeat(64),
    isValid: true,
  };
}
