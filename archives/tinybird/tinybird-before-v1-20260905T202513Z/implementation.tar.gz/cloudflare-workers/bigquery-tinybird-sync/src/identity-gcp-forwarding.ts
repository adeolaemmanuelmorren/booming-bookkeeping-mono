import type {
  IdentityEngineResult,
  IdentityJournalRow,
} from "./identity-engine";
import type { IdentityCompactionManifest } from "./tinybird-api";
import type { Fetcher } from "./bigquery";

const ROWS_PATH = "/v1/identity-batches/chunks";
const ACTIVATION_PATH = "/v1/identity-batches/activate";
const ROWS_PER_CHUNK = 200;
const MAX_CHUNK_BYTES = 4 * 1024 * 1024;
const DEFAULT_TIMEOUT_MS = 30_000;

export const IDENTITY_GCP_FORWARDING_ERROR_PREFIX =
  "Identity GCP forwarding failed: ";

export interface IdentityGcpIngestConfig {
  baseUrl: string;
  token: string;
  timeoutMs: number;
}

export interface IdentityGcpIngestEnv {
  IDENTITY_GCP_INGEST_URL?: string;
  IDENTITY_GCP_INGEST_TOKEN?: string;
  IDENTITY_GCP_INGEST_TIMEOUT_MS?: string;
}

interface ForwardingManifest {
  tenantId: string;
  batchVersion: number;
  batchId: string;
  inputEventCount: number;
  inputHash: string;
  outputRowCount: number;
  outputHash: string;
  checkpointIngestedAt: string;
  checkpointEventId: string;
}

export class IdentityGcpForwardingError extends Error {
  constructor(
    message: string,
    readonly status: number | null,
  ) {
    super(`${IDENTITY_GCP_FORWARDING_ERROR_PREFIX}${message}`);
    this.name = "IdentityGcpForwardingError";
  }
}

export function identityGcpIngestConfig(
  env: IdentityGcpIngestEnv,
): IdentityGcpIngestConfig | null {
  const baseUrl = env.IDENTITY_GCP_INGEST_URL?.trim() ?? "";
  const token = env.IDENTITY_GCP_INGEST_TOKEN?.trim() ?? "";

  if (!baseUrl && !token) return null;
  if (!baseUrl) throw new Error("IDENTITY_GCP_INGEST_URL is required when forwarding is enabled.");
  if (!token) throw new Error("IDENTITY_GCP_INGEST_TOKEN is required when forwarding is enabled.");

  const url = new URL(baseUrl);
  if (url.protocol !== "https:") {
    throw new Error("IDENTITY_GCP_INGEST_URL must use HTTPS.");
  }

  return {
    baseUrl: baseUrl.replace(/\/+$/g, ""),
    token,
    timeoutMs: positiveInteger(
      env.IDENTITY_GCP_INGEST_TIMEOUT_MS ?? String(DEFAULT_TIMEOUT_MS),
      "IDENTITY_GCP_INGEST_TIMEOUT_MS",
    ),
  };
}

export async function forwardIdentityRows(
  engine: IdentityEngineResult,
  config: IdentityGcpIngestConfig | null,
  fetcher: Fetcher = fetch,
): Promise<void> {
  if (!config) return;

  const manifest = forwardingManifestFromEngine(engine);
  const chunks = chunkRows(engine.rows, ROWS_PER_CHUNK, MAX_CHUNK_BYTES);

  for (let chunkIndex = 0; chunkIndex < chunks.length; chunkIndex += 1) {
    const rows = chunks[chunkIndex];
    await postJson(ROWS_PATH, {
      schemaVersion: 1,
      event: "identity.batch.rows",
      manifest,
      chunkIndex,
      chunkCount: chunks.length,
      rowCount: rows.length,
      chunkHash: await outputRowsHash(rows),
      rows,
    }, config, fetcher);
  }
}

export async function forwardIdentityActivation(
  manifest: IdentityCompactionManifest,
  config: IdentityGcpIngestConfig | null,
  fetcher: Fetcher = fetch,
): Promise<void> {
  if (!config) return;

  await postJson(ACTIVATION_PATH, {
    schemaVersion: 1,
    event: "identity.batch.activated",
    manifest: forwardingManifestFromCompaction(manifest),
    activatedAt: new Date().toISOString(),
  }, config, fetcher);
}

function forwardingManifestFromEngine(
  engine: IdentityEngineResult,
): ForwardingManifest {
  const manifest = engine.manifest;
  return {
    tenantId: manifest.tenant_id,
    batchVersion: manifest.batch_version,
    batchId: manifest.batch_id,
    inputEventCount: manifest.input_event_count,
    inputHash: manifest.input_hash,
    outputRowCount: manifest.output_row_count,
    outputHash: manifest.output_hash,
    checkpointIngestedAt: manifest.checkpoint_ingested_at,
    checkpointEventId: manifest.checkpoint_event_id,
  };
}

function forwardingManifestFromCompaction(
  manifest: IdentityCompactionManifest,
): ForwardingManifest {
  return {
    tenantId: manifest.tenantId,
    batchVersion: manifest.batchVersion,
    batchId: manifest.batchId,
    inputEventCount: manifest.inputEventCount,
    inputHash: manifest.inputHash,
    outputRowCount: manifest.actualOutputRowCount,
    outputHash: manifest.actualOutputHash,
    checkpointIngestedAt: manifest.checkpointIngestedAt,
    checkpointEventId: manifest.checkpointEventId,
  };
}

async function postJson(
  path: string,
  body: object,
  config: IdentityGcpIngestConfig,
  fetcher: Fetcher,
): Promise<void> {
  let response: Response;

  try {
    response = await fetcher(`${config.baseUrl}${path}`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${config.token}`,
        "Content-Type": "application/json; charset=utf-8",
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(config.timeoutMs),
    });
  } catch (error) {
    if (error instanceof IdentityGcpForwardingError) throw error;
    const message = error instanceof Error ? error.message : String(error);
    throw new IdentityGcpForwardingError(message, null);
  }

  if (response.ok) return;

  const details = (await response.text()).slice(0, 1_000);
  throw new IdentityGcpForwardingError(
    `${response.status} ${details || response.statusText}`.trim(),
    response.status,
  );
}

function chunkRows(
  rows: IdentityJournalRow[],
  maximumRows: number,
  maximumBytes: number,
): IdentityJournalRow[][] {
  const result: IdentityJournalRow[][] = [];
  let current: IdentityJournalRow[] = [];
  let currentBytes = 0;

  for (const row of rows) {
    const rowBytes = new TextEncoder().encode(JSON.stringify(row)).length;
    if (rowBytes > maximumBytes) {
      throw new IdentityGcpForwardingError(
        `one identity row exceeds the ${maximumBytes}-byte chunk limit`,
        null,
      );
    }
    if (
      current.length > 0
      && (current.length >= maximumRows || currentBytes + rowBytes > maximumBytes)
    ) {
      result.push(current);
      current = [];
      currentBytes = 0;
    }
    current.push(row);
    currentBytes += rowBytes;
  }
  if (current.length > 0) result.push(current);
  return result;
}

async function outputRowsHash(rows: IdentityJournalRow[]): Promise<string> {
  const values = rows.map(outputRowKey).sort();
  return sha256Hex(values.join("|"));
}

function outputRowKey(row: IdentityJournalRow): string {
  return `${row.state_kind}:${row.lookup_key}:${row.sub_key}:${row.row_hash}`;
}

async function sha256Hex(value: string): Promise<string> {
  const bytes = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)]
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
}

function positiveInteger(value: string, name: string): number {
  const parsed = Number(value);
  if (Number.isSafeInteger(parsed) && parsed > 0) return parsed;
  throw new Error(`${name} must be a positive integer.`);
}
