# Identity GCP forwarding

## Problem

The identity Worker already computes the exact changed facts, mappings, profiles, and tombstones for one bounded batch. BigQuery needs a copy of those results without running a second identity graph. The handoff must survive retries, must not expose a partial batch, and must not require one request large enough to hit Cloud Run's request limit.

## Usage

The Worker sends rows in bounded chunks while the computed batch is still in memory:

```ts
await forwardIdentityRows({
  manifest,
  rows: engine.rows,
}, gcpIngestConfig);
```

After Tinybird confirms that the same batch is active, the Worker sends the receipt that makes the staged rows eligible for downstream use:

```ts
await forwardIdentityActivation(manifest, gcpIngestConfig);
```

The Cloud Run service exposes only three routes:

```text
GET  /healthz
POST /v1/identity-batches/chunks
POST /v1/identity-batches/activate
```

## Shape

`IdentityBatchManifest` identifies one immutable logical batch. `IdentityRowChunk` contains a bounded subset of that batch and a hash of its row identities. `IdentityActivationReceipt` contains the already-validated batch count and hash.

The Worker owns chunking and delivery. The Cloud Run service owns authentication, validation, and BigQuery persistence. BigQuery owns durable staging and receipt-gated visibility. Callers do not coordinate BigQuery inserts or retries themselves.

The landing tables are append-only. A deterministic insert ID makes ordinary retries cheap. Queries still deduplicate by the full logical row key because BigQuery streaming insert deduplication is best effort. The activation endpoint recomputes the distinct row count and output hash from staged rows before writing a receipt.

The handoff is optional until both `IDENTITY_GCP_INGEST_URL` and `IDENTITY_GCP_INGEST_TOKEN` are configured. Once configured, delivery failures block identity publication and retry from the Durable Object. This prevents silent gaps.

## Synthesis decision

The design combines the smallest existing Cloud Run pattern with the Worker's current activation contract. A single large post-activation upload was rejected because the coordinator no longer holds the rows and one expanded identity component can make the request too large. A pointer-only notification was rejected for this first slice because it would require Cloud Run to own Tinybird credentials and a second paging client. Chunked pre-activation staging plus a post-activation receipt keeps each side's interface small and makes incomplete data unusable.

## Tradeoffs accepted

- We accept staged rows that may never receive a receipt in exchange for keeping Tinybird and BigQuery publication independent and recoverable.
- We accept one small validation query per activated batch in exchange for proving that BigQuery received the exact distinct row set.
- We accept a shared transport secret for the first deployment in exchange for matching the repository's existing Cloud Run pattern. Workload identity can replace it later without changing the batch contract.

## Alternatives considered

- Cloud Run could receive only a batch pointer and pull rows from Tinybird. This hides payload size but gives the GCP service Tinybird credentials and duplicates the paging protocol.
- Cloud Run could write immutable files to GCS and submit deterministic BigQuery load jobs. This gives stronger physical batch atomicity, but adds bucket IAM, object lifecycle, and load-job coordination before the first landing path exists.
- Pub/Sub would buffer delivery, but it adds a topic, subscription, dead-letter policy, and another at-least-once boundary without removing the need for idempotency.

## Deployment questions and risks

- The checked-in table definitions default to `dataform_realtime`; the service keeps the dataset configurable so this can be changed before deployment.
- How long should unreceipted staged rows remain before cleanup?
- Should the shared transport secret be replaced with Google-issued identity tokens before production traffic is enabled?

## Current implementation boundary

The transport, receiver, landing tables, and activation gate are implemented. Deployment, table creation, historical backfill, and Dataform consumption are intentionally outside this first slice.
