# Meta Ads query API

Private Cloud Run service that reads Meta Ads Insights when the dashboard asks
for a report. It does not write to BigQuery and has no scheduler.

The service reads the system-user token from Google Secret Manager. Callers
never receive the token. Cloud Run IAM limits access to the Bill reporting API.

## Endpoints

- `GET /healthz`
- `GET /v1/meta-ads/performance?start_date=YYYY-MM-DD&end_date=YYYY-MM-DD`
- `GET /v1/meta-ads/hourly-performance?start_date=YYYY-MM-DD&end_date=YYYY-MM-DD`
- `GET /v1/meta-ads/delivery?start_date=YYYY-MM-DD&end_date=YYYY-MM-DD`
- `GET /v1/meta-ads/dashboard?start_date=YYYY-MM-DD&end_date=YYYY-MM-DD`

`performance` matches the columns in `stg_facebook_ads`. Meta does not return a
usable landing-page URL for every creative, so `landing_page_url` can be null.
`hourly-performance` matches `stg_facebook_ads_hourly`. `delivery` keeps reach
and frequency separate at campaign, ad set, and ad level.

Responses use a five-minute in-memory cache. Meta may revise recent delivery
and conversion metrics after the first response.

Multi-day action reports use Meta's asynchronous Insights API because the
synchronous request can fail even for a week of data. The service starts a
report on demand, waits for completion, then reads every result page. A retry
resumes a still-running report for up to 15 minutes. Partial results are never
returned. This does not add a scheduled sync or a warehouse write.

## Required configuration

See `.env.example`. The token needs `ads_read` access to the configured ad
account. Never put the token in the repository.
