import assert from "node:assert/strict";
import test from "node:test";
import { createMetaClient } from "../src/meta-client.js";

test("reads every Insights page and sends the token as a header", async () => {
  const requests = [];
  const responses = [
    {
      data: [{ ad_id: "1" }],
      paging: { next: "https://graph.facebook.com/next-page" },
    },
    { data: [{ ad_id: "2" }] },
  ];
  const client = createMetaClient({
    accessToken: "secret-token",
    accountId: "123",
    apiVersion: "v25.0",
    fetchImpl: async (url, options) => {
      requests.push({ url, options });
      return new Response(JSON.stringify(responses.shift()), { status: 200 });
    },
  });

  const rows = await client.getInsights({ fields: "ad_id" });

  assert.deepEqual(rows, [{ ad_id: "1" }, { ad_id: "2" }]);
  assert.equal(requests.length, 2);
  assert.equal(requests[0].options.headers.Authorization, "Bearer secret-token");
  assert.equal(requests[0].url.includes("secret-token"), false);
});

test("returns a safe Meta error with the request id", async () => {
  const client = createMetaClient({
    accessToken: "secret-token",
    accountId: "123",
    apiVersion: "v25.0",
    fetchImpl: async () =>
      new Response(
        JSON.stringify({ error: { code: 190, message: "Invalid token" } }),
        { status: 401, headers: { "x-fb-trace-id": "trace-1" } },
      ),
  });

  await assert.rejects(
    client.getInsights({ fields: "ad_id" }),
    (error) => {
      assert.match(error.message, /code 190/);
      assert.equal(error.requestId, "trace-1");
      assert.equal(error.message.includes("secret-token"), false);
      return true;
    },
  );
});

test("multi-day action reports wait for completion and read every result page", async () => {
  const requests = [];
  const responses = [{ report_run_id: "123" }, { async_status: "Job Running", async_percent_completion: 50 },
    { async_status: "Job Completed", async_percent_completion: 100 },
    { data: [{ ad_id: "1" }], paging: { next: "https://graph.facebook.com/result-next" } },
    { data: [{ ad_id: "2" }] }];
  const client = createMetaClient({ accessToken: "secret", accountId: "456", apiVersion: "v25.0", sleep: async () => {},
    fetchImpl: async (url, options) => { requests.push({ url, options }); return Response.json(responses.shift()); } });
  const params = { fields: "ad_id,actions", time_range: JSON.stringify({ since: "2026-09-01", until: "2026-09-05" }), time_increment: 1 };
  assert.deepEqual(await client.getInsights(params), [{ ad_id: "1" }, { ad_id: "2" }]);
  assert.equal(requests[0].options.method, "POST");
  assert.equal(new URLSearchParams(requests[0].options.body).get("time_range"), params.time_range);
  assert.ok(requests.every(request => request.options.headers.Authorization === "Bearer secret"));
  assert.ok(requests.every(request => !request.url.includes("secret")));
});

test("a slow Meta report resumes its existing job on retry", async () => {
  let starts = 0;
  let polls = 0;
  const client = createMetaClient({ accessToken: "secret", accountId: "456", apiVersion: "v25.0", maxPolls: 1,
    fetchImpl: async (url, options) => {
      if (options.method === "POST") { starts++; return Response.json({ report_run_id: "123" }); }
      if (url.includes("/123/insights")) return Response.json({ data: [{ ad_id: "1" }] });
      polls++;
      return Response.json({ async_status: polls === 1 ? "Job Running" : "Job Completed", async_percent_completion: polls === 1 ? 50 : 100 });
    } });
  const params = { fields: "ad_id,actions", time_range: JSON.stringify({ since: "2026-09-01", until: "2026-09-05" }) };
  await assert.rejects(client.getInsights(params), /still preparing/);
  assert.deepEqual(await client.getInsights(params), [{ ad_id: "1" }]);
  assert.equal(starts, 1);
});
