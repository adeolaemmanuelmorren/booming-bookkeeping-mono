import assert from "node:assert/strict";
import test from "node:test";
import { createRequestHandler } from "../src/app.js";

test("serves dashboard rows with a five-minute cache header", async () => {
  const handle = createRequestHandler({
    loaders: {
      loadDashboard: async (range) => ({
        ...range,
        hourlyRows: [],
        deliveryRows: [],
      }),
    },
    maxRangeDays: 366,
    cacheSeconds: 300,
  });
  const response = await handle({
    method: "GET",
    url: "/v1/meta-ads/dashboard?start_date=2026-09-01&end_date=2026-09-05",
  });

  assert.equal(response.status, 200);
  assert.equal(response.headers["cache-control"], "private, max-age=300");
  assert.deepEqual(JSON.parse(response.body).hourlyRows, []);
});
