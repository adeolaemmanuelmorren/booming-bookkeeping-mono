import assert from "node:assert/strict";
import test from "node:test";
import {
  InvalidDateRangeError,
  parseDateRange,
} from "../src/date-window.js";

test("accepts an inclusive date range", () => {
  assert.deepEqual(
    parseDateRange({
      startDate: "2026-09-01",
      endDate: "2026-09-05",
      maxRangeDays: 10,
    }),
    { startDate: "2026-09-01", endDate: "2026-09-05" },
  );
});

test("rejects an oversized date range", () => {
  assert.throws(
    () =>
      parseDateRange({
        startDate: "2026-09-01",
        endDate: "2026-09-05",
        maxRangeDays: 4,
      }),
    InvalidDateRangeError,
  );
});
