import assert from "node:assert/strict";
import test from "node:test";
import { dailyRows, deliveryRows, hourlyRows } from "../src/rows.js";

const rawAd = {
  date_start: "2026-09-05",
  account_id: "10",
  account_name: "Bill",
  account_currency: "USD",
  campaign_id: "20",
  campaign_name: "Campaign",
  adset_id: "30",
  adset_name: "Ad set",
  ad_id: "40",
  ad_name: "Ad",
  impressions: "100",
  inline_link_clicks: "8",
  spend: "12.50",
};

test("maps Meta hourly Insights to the staging shape", () => {
  const [row] = hourlyRows(
    [{
      ...rawAd,
      hourly_stats_aggregated_by_advertiser_time_zone:
        "13:00:00 - 13:59:59",
    }],
    "2026-09-05T20:10:00.000Z",
  );

  assert.equal(row.hour_start, "2026-09-05T13:00:00");
  assert.equal(row.clicks, 8);
  assert.equal(row.spend, 12.5);
});

test("maps purchase actions to the daily staging shape", () => {
  const [row] = dailyRows(
    [{
      ...rawAd,
      actions: [{ action_type: "offsite_conversion.fb_pixel_purchase", value: "2" }],
      action_values: [
        { action_type: "offsite_conversion.fb_pixel_purchase", value: "198" },
      ],
    }],
    "2026-09-05T20:10:00.000Z",
  );

  assert.equal(row.platform_conversions, 2);
  assert.equal(row.platform_conversion_value, 198);
  assert.equal(row.unique_inline_link_clicks, 8);
});

test("keeps reach separate at each delivery level", () => {
  const rows = deliveryRows(
    {
      campaign: [{ ...rawAd, reach: "80" }],
      adset: [{ ...rawAd, reach: "70" }],
      ad: [{ ...rawAd, reach: "60" }],
    },
    "2026-09-05T20:10:00.000Z",
  );

  assert.deepEqual(rows.map((row) => row.level), ["campaign", "adset", "ad"]);
  assert.equal(rows[0].adset_id, null);
  assert.equal(rows[1].ad_id, null);
  assert.equal(rows[2].frequency, 100 / 60);
});
