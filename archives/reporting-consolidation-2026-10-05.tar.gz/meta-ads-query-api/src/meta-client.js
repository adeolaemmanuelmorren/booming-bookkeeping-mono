const GRAPH_BASE_URL = "https://graph.facebook.com";

export function createMetaClient({
  accessToken,
  accountId,
  apiVersion,
  fetchImpl = fetch,
  sleep = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds)),
  maxPolls = 25,
  now = Date.now,
}) {
  const accountPath = `${apiVersion}/act_${accountId}`;
  const reports = new Map();

  async function getInsights(params) {
    const range = params.time_range ? JSON.parse(params.time_range) : null;
    const dailyActions = params.fields?.split(",").includes("actions") && range?.since !== range?.until;
    if (dailyActions || reports.has(JSON.stringify(params))) return getAsyncInsights(params);
    try {
      return await getAll(`${accountPath}/insights`, params);
    } catch (error) {
      if (!error.retryable) throw error;
      return getAsyncInsights(params);
    }
  }

  async function request(url, options = {}) {
    const response = await fetchImpl(url, { ...options,
      headers: { Authorization: `Bearer ${accessToken}`, ...options.headers },
      signal: AbortSignal.timeout(60_000) });
    const body = await readJson(response);
    if (!response.ok || body.error) {
      const error = new Error(metaErrorMessage(response.status, body));
      error.requestId = response.headers.get("x-fb-trace-id");
      error.retryable = response.status >= 500 || [1, 2].includes(body.error?.code) || body.error?.is_transient === true;
      throw error;
    }
    return body;
  }

  // Meta can reject synchronous action reports even for a short date range.
  // This creates a read-only Insights report, then reads its complete result.
  // Keep the report ID across retries so a slow report is resumed, not restarted.
  async function getAsyncInsights(params) {
    const key = JSON.stringify(params);
    let report = reports.get(key);
    if (!report || report.expiresAt <= now()) {
      const body = await request(createUrl(`${accountPath}/insights`, {}), {
        method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams(Object.entries(params).map(([name, value]) => [name, String(value)])).toString(),
      });
      if (!/^\d+$/.test(String(body.report_run_id ?? ""))) throw new Error("Meta did not return an Insights report ID.");
      report = { id: String(body.report_run_id), expiresAt: now() + 900_000 };
      if (reports.size >= 100) reports.delete(reports.keys().next().value);
      reports.set(key, report);
    }
    for (let attempt = 0; attempt < maxPolls; attempt++) {
      const status = await request(createUrl(`${apiVersion}/${report.id}`, {
        fields: "async_status,async_percent_completion",
      }));
      if (status.async_status === "Job Completed" && Number(status.async_percent_completion) === 100) {
        const rows = await getAll(`${apiVersion}/${report.id}/insights`, { limit: params.limit ?? 500 });
        reports.delete(key);
        return rows;
      }
      if (["Job Failed", "Job Skipped"].includes(status.async_status)) {
        reports.delete(key);
        throw new Error("Meta Insights report failed before completion.");
      }
      if (attempt + 1 < maxPolls) await sleep(2000);
    }
    throw new Error("Meta Insights report is still preparing; retry will resume it.");
  }

  async function getAll(path, params) {
    let nextUrl = createUrl(path, params);
    const rows = [];

    while (nextUrl) {
      const body = await request(nextUrl);

      if (!Array.isArray(body.data)) {
        throw new Error("Meta Ads response has no data array.");
      }

      rows.push(...body.data);
      nextUrl = body.paging?.next ?? null;
    }

    return rows;
  }

  return { getInsights };
}

function createUrl(path, params) {
  const url = new URL(`${GRAPH_BASE_URL}/${path.replace(/^\/+/, "")}`);

  for (const [name, value] of Object.entries(params)) {
    if (value === null || value === undefined) continue;
    url.searchParams.set(name, String(value));
  }

  return url.toString();
}

async function readJson(response) {
  const text = await response.text();

  try {
    return JSON.parse(text);
  } catch {
    throw new Error(`Meta Ads returned HTTP ${response.status} with invalid JSON.`);
  }
}

function metaErrorMessage(status, body) {
  const message = body.error?.message ?? "Unknown Meta Ads error.";
  const code = body.error?.code ?? "unknown";
  return `Meta Ads returned HTTP ${status}, code ${code}: ${message}`;
}
