const COMMON_FIELDS = [
  "account_id",
  "account_name",
  "account_currency",
  "campaign_id",
  "campaign_name",
  "adset_id",
  "adset_name",
  "ad_id",
  "ad_name",
  "impressions",
  "inline_link_clicks",
  "spend",
];

export function hourlyInsightsQuery(range) {
  return {
    level: "ad",
    time_increment: 1,
    time_range: JSON.stringify({
      since: range.startDate,
      until: range.endDate,
    }),
    breakdowns: "hourly_stats_aggregated_by_advertiser_time_zone",
    fields: COMMON_FIELDS.join(","),
    limit: 500,
  };
}

export function dailyInsightsQuery(range) {
  return {
    level: "ad",
    time_increment: 1,
    time_range: JSON.stringify({
      since: range.startDate,
      until: range.endDate,
    }),
    fields: [
      ...COMMON_FIELDS,
      "unique_clicks",
      "actions",
      "action_values",
    ].join(","),
    limit: 500,
  };
}

export function deliveryInsightsQuery(range, level) {
  return {
    level,
    time_increment: 1,
    time_range: JSON.stringify({
      since: range.startDate,
      until: range.endDate,
    }),
    fields: [
      "account_id",
      "campaign_id",
      "campaign_name",
      "adset_id",
      "adset_name",
      "ad_id",
      "ad_name",
      "impressions",
      "spend",
      "reach",
    ].join(","),
    limit: 500,
  };
}
