import { InvalidDateRangeError, parseDateRange } from "./date-window.js";

const ROUTES = new Map([
  ["/v1/meta-ads/performance", "loadDaily"],
  ["/v1/meta-ads/hourly-performance", "loadHourly"],
  ["/v1/meta-ads/delivery", "loadDelivery"],
  ["/v1/meta-ads/dashboard", "loadDashboard"],
]);

export function createRequestHandler({ loaders, maxRangeDays, cacheSeconds }) {
  return async function handleRequest(request) {
    const url = new URL(request.url, "http://localhost");

    if (request.method === "GET" && url.pathname === "/healthz") {
      return jsonResponse(200, { status: "ok" });
    }

    const loaderName = ROUTES.get(url.pathname);

    if (request.method !== "GET" || !loaderName) {
      return jsonResponse(404, { error: "Not found." });
    }

    try {
      const range = parseDateRange({
        startDate: url.searchParams.get("start_date"),
        endDate: url.searchParams.get("end_date"),
        maxRangeDays,
      });
      const result = await loaders[loaderName](range);

      return jsonResponse(200, result, {
        "cache-control": `private, max-age=${cacheSeconds}`,
      });
    } catch (error) {
      if (error instanceof InvalidDateRangeError) {
        return jsonResponse(400, { error: error.message });
      }

      console.error("Meta Ads request failed.", error);
      return jsonResponse(500, {
        error: "Meta Ads request failed.",
        requestId: error.requestId ?? null,
      });
    }
  };
}

function jsonResponse(status, body, extraHeaders = {}) {
  return {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      ...extraHeaders,
    },
    body: JSON.stringify(body),
  };
}
