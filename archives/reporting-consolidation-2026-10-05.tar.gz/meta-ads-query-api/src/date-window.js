const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

export class InvalidDateRangeError extends Error {}

export function parseDateRange({ startDate, endDate, maxRangeDays }) {
  if (!DATE_PATTERN.test(startDate ?? "")) {
    throw new InvalidDateRangeError("start_date must use YYYY-MM-DD.");
  }

  if (!DATE_PATTERN.test(endDate ?? "")) {
    throw new InvalidDateRangeError("end_date must use YYYY-MM-DD.");
  }

  const start = parseDate(startDate);
  const end = parseDate(endDate);

  if (end < start) {
    throw new InvalidDateRangeError("end_date must not be before start_date.");
  }

  const rangeDays = Math.floor((end - start) / 86_400_000) + 1;

  if (rangeDays > maxRangeDays) {
    throw new InvalidDateRangeError(
      `Date range must not exceed ${maxRangeDays} days.`,
    );
  }

  return { startDate, endDate };
}

function parseDate(value) {
  const date = new Date(`${value}T00:00:00.000Z`);

  if (Number.isNaN(date.getTime()) || date.toISOString().slice(0, 10) !== value) {
    throw new InvalidDateRangeError("Date is not valid.");
  }

  return date;
}
