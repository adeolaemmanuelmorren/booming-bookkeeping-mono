import {
  dailyInsightsQuery,
  deliveryInsightsQuery,
  hourlyInsightsQuery,
} from "./queries.js";
import { dailyRows, deliveryRows, hourlyRows } from "./rows.js";

export function createPerformanceLoader({ metaClient, cacheSeconds, now = Date.now }) {
  const cache = new Map();
  const pendingLoads = new Map();
  const cacheTtlMs = cacheSeconds * 1_000;

  async function cachedLoad(type, range, load) {
    const key = `${type}:${range.startDate}:${range.endDate}`;
    const cached = cache.get(key);

    if (cached && cached.expiresAt > now()) return cached.value;
    if (pendingLoads.has(key)) return pendingLoads.get(key);

    const pending = load()
      .then((value) => {
        cache.set(key, { value, expiresAt: now() + cacheTtlMs });
        return value;
      })
      .finally(() => pendingLoads.delete(key));

    pendingLoads.set(key, pending);
    return pending;
  }

  function loadHourly(range) {
    return cachedLoad("hourly", range, async () => {
      const fetchedAt = new Date().toISOString();
      const rawRows = await metaClient.getInsights(hourlyInsightsQuery(range));
      return result(range, fetchedAt, hourlyRows(rawRows, fetchedAt));
    });
  }

  function loadDaily(range) {
    return cachedLoad("daily", range, async () => {
      const fetchedAt = new Date().toISOString();
      const rawRows = await metaClient.getInsights(dailyInsightsQuery(range));
      return result(range, fetchedAt, dailyRows(rawRows, fetchedAt));
    });
  }

  function loadDelivery(range) {
    return cachedLoad("delivery", range, async () => {
      const fetchedAt = new Date().toISOString();
      const levels = ["campaign", "adset", "ad"];
      const responses = await Promise.all(
        levels.map((level) =>
          metaClient.getInsights(deliveryInsightsQuery(range, level)),
        ),
      );
      const rowsByLevel = Object.fromEntries(
        levels.map((level, index) => [level, responses[index]]),
      );

      return result(range, fetchedAt, deliveryRows(rowsByLevel, fetchedAt));
    });
  }

  async function loadDashboard(range) {
    const [hourly, delivery] = await Promise.all([
      loadHourly(range),
      loadDelivery(range),
    ]);

    return {
      ...range,
      fetchedAt: laterTimestamp(hourly.fetchedAt, delivery.fetchedAt),
      hourlyRows: hourly.rows,
      deliveryRows: delivery.rows,
    };
  }

  return { loadHourly, loadDaily, loadDelivery, loadDashboard };
}

function result(range, fetchedAt, rows) {
  return { ...range, fetchedAt, rows };
}

function laterTimestamp(left, right) {
  return left > right ? left : right;
}
