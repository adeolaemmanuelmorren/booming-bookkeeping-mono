import { createServer } from "node:http";
import { createRequestHandler } from "./app.js";
import { readConfig } from "./config.js";
import { createMetaClient } from "./meta-client.js";
import { createPerformanceLoader } from "./performance.js";

const config = readConfig();
const metaClient = createMetaClient(config);
const loaders = createPerformanceLoader({
  metaClient,
  cacheSeconds: config.cacheSeconds,
});
const handleRequest = createRequestHandler({
  loaders,
  maxRangeDays: config.maxRangeDays,
  cacheSeconds: config.cacheSeconds,
});
const port = Number(process.env.PORT ?? 8080);

const server = createServer(async (request, response) => {
  const result = await handleRequest(request);
  response.writeHead(result.status, result.headers);
  response.end(result.body);
});

server.listen(port, "0.0.0.0", () => {
  console.log(`Meta Ads query API listening on port ${port}.`);
});
