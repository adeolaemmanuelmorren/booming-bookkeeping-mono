const DEFAULTS = {
  accountId: "10151088695453802",
  apiVersion: "v25.0",
  cacheSeconds: 300,
  maxRangeDays: 366,
};

export function readConfig(env = process.env) {
  const accessToken = env.META_ADS_ACCESS_TOKEN;

  if (!accessToken) {
    throw new Error("META_ADS_ACCESS_TOKEN is required.");
  }

  return {
    accessToken,
    accountId: digitsOnly(env.META_ADS_ACCOUNT_ID ?? DEFAULTS.accountId),
    apiVersion: env.META_ADS_API_VERSION ?? DEFAULTS.apiVersion,
    cacheSeconds: positiveInteger(
      env.META_ADS_CACHE_SECONDS ?? DEFAULTS.cacheSeconds,
      "META_ADS_CACHE_SECONDS",
    ),
    maxRangeDays: positiveInteger(
      env.META_ADS_MAX_RANGE_DAYS ?? DEFAULTS.maxRangeDays,
      "META_ADS_MAX_RANGE_DAYS",
    ),
  };
}

function digitsOnly(value) {
  const normalized = String(value).replace(/^act_/, "");

  if (!/^\d+$/.test(normalized)) {
    throw new Error("META_ADS_ACCOUNT_ID must contain digits only.");
  }

  return normalized;
}

function positiveInteger(value, name) {
  const parsed = Number(value);

  if (!Number.isInteger(parsed) || parsed < 1) {
    throw new Error(`${name} must be a positive integer.`);
  }

  return parsed;
}
