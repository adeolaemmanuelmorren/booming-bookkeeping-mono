const PURCHASE_ACTION = "offsite_conversion.fb_pixel_purchase";

export function hourlyRows(rows, fetchedAt) {
  return rows.map((row) => {
    const hourBucket = row.hourly_stats_aggregated_by_advertiser_time_zone;
    const hour = hourBucket?.split(" - ")[0] ?? "00:00:00";

    return {
      hour_start: `${row.date_start}T${hour}`,
      date: row.date_start,
      hour_bucket: hourBucket,
      hour_breakdown_type: "advertiser",
      account_id: row.account_id,
      account_name: emptyToNull(row.account_name),
      campaign_id: row.campaign_id,
      campaign_name: emptyToNull(row.campaign_name),
      adset_id: row.adset_id,
      adset_name: emptyToNull(row.adset_name),
      ad_id: row.ad_id,
      ad_name: emptyToNull(row.ad_name),
      landing_page_url: null,
      impressions: integer(row.impressions),
      clicks: integer(row.inline_link_clicks),
      spend: number(row.spend),
      currency: row.account_currency ?? "USD",
      _dataform_updated_at: fetchedAt,
    };
  });
}

export function dailyRows(rows, fetchedAt) {
  return rows.map((row) => {
    const clicks = integer(row.inline_link_clicks);

    return {
      time: `${row.date_start}T00:00:00`,
      account_id: row.account_id,
      account_name: emptyToNull(row.account_name),
      campaign_id: row.campaign_id,
      campaign_name: emptyToNull(row.campaign_name),
      adset_id: row.adset_id,
      adset_name: emptyToNull(row.adset_name),
      ad_id: row.ad_id,
      ad_name: emptyToNull(row.ad_name),
      landing_page_url: null,
      impressions: integer(row.impressions),
      clicks,
      unique_clicks: clicks,
      unique_inline_link_clicks: clicks,
      spend: number(row.spend),
      platform_conversions: actionValue(row.actions),
      platform_conversion_value: actionValue(row.action_values),
      currency: row.account_currency ?? "USD",
      _dataform_updated_at: fetchedAt,
    };
  });
}

export function deliveryRows(rowsByLevel, fetchedAt) {
  return Object.entries(rowsByLevel).flatMap(([level, rows]) =>
    rows
      .map((row) => deliveryRow(row, level, fetchedAt))
      .filter((row) => row.impressions > 0 || row.spend > 0),
  );
}

function deliveryRow(row, level, fetchedAt) {
  const impressions = integer(row.impressions);
  const reach = integer(row.reach);

  return {
    date: row.date_start,
    level,
    account_id: row.account_id,
    campaign_id: row.campaign_id,
    adset_id: level === "campaign" ? null : row.adset_id,
    ad_id: level === "ad" ? row.ad_id : null,
    campaign_name: emptyToNull(row.campaign_name),
    adset_name: level === "campaign" ? null : emptyToNull(row.adset_name),
    ad_name: level === "ad" ? emptyToNull(row.ad_name) : null,
    impressions,
    spend: number(row.spend),
    reach,
    frequency: reach === 0 ? null : impressions / reach,
    currency: "USD",
    _dataform_updated_at: fetchedAt,
  };
}

function actionValue(actions) {
  const match = actions?.find((action) => action.action_type === PURCHASE_ACTION);
  return number(match?.value);
}

function integer(value) {
  const parsed = Number(value ?? 0);
  return Number.isFinite(parsed) ? Math.trunc(parsed) : 0;
}

function number(value) {
  const parsed = Number(value ?? 0);
  return Number.isFinite(parsed) ? parsed : 0;
}

function emptyToNull(value) {
  const normalized = String(value ?? "").trim();
  return normalized || null;
}
