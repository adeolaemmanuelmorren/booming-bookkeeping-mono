import test from "node:test";
import assert from "node:assert/strict";
import { adRows, campaignRows, stagingRows } from "../src/rows.js";

const baseResult = {
  segments: { date: "2026-09-04" },
  customer: { id: "1941192637", descriptiveName: "Boom", currencyCode: "USD" },
  campaign: { id: "10", name: "Campaign", advertisingChannelType: "SEARCH" },
  metrics: {
    impressions: "100",
    clicks: "7",
    costMicros: "12340000",
    conversions: 2.5,
    conversionsValue: 300,
  },
};

test("maps an ad result without losing integer precision", () => {
  const result = {
    ...baseResult,
    adGroup: { id: "20", name: "Group" },
    adGroupAd: {
      ad: { id: "30", name: "Ad", finalUrls: ["https://example.com"] },
    },
  };

  const [row] = adRows([result], "2026-09-04T12:00:00.000Z");

  assert.equal(row.cost_micros, "12340000");
  assert.equal(row.landing_page_url, "https://example.com");
  assert.equal(row.lowest_grain_type, "ad");
});

test("maps Performance Max at campaign grain", () => {
  const result = {
    ...baseResult,
    campaign: {
      ...baseResult.campaign,
      advertisingChannelType: "PERFORMANCE_MAX",
    },
  };

  const [row] = campaignRows([result], "2026-09-04T12:00:00.000Z");

  assert.equal(row.adset_id, "pmax_smart");
  assert.equal(row.ad_id, "pmax_smart");
  assert.equal(row.lowest_grain_type, "campaign");
});

test("returns the stg_google_ads metric shape", () => {
  const result = {
    ...baseResult,
    adGroup: { id: "20", name: "Group" },
    adGroupAd: { ad: { id: "30", name: "Ad" } },
  };
  const sourceRows = adRows([result], "2026-09-04T12:00:00.000Z");
  const [row] = stagingRows(sourceRows);

  assert.equal(row.time, "2026-09-04T00:00:00");
  assert.equal(row.spend, 12.34);
  assert.equal(row.unique_clicks, 7);
  assert.equal(row.platform_conversions, 2.5);
  assert.equal(row._dataform_updated_at, "2026-09-04T12:00:00.000Z");
  assert.equal("cost_micros" in row, false);
});
