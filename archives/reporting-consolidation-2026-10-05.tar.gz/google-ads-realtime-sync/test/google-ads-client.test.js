import test from "node:test";
import assert from "node:assert/strict";
import { createGoogleAdsClient } from "../src/google-ads-client.js";

test("sends the developer token and flattens streamed batches", async () => {
  const requests = [];
  const client = createGoogleAdsClient({
    customerId: "1941192637",
    loginCustomerId: "1234567890",
    developerToken: "test-token",
    apiVersion: "v25",
    auth: {
      async getClient() {
        return {
          async getRequestHeaders() {
            return new Headers({ authorization: "Bearer access-token" });
          },
        };
      },
    },
    async fetchImpl(url, init) {
      requests.push({ url, init });
      return {
        ok: true,
        async json() {
          return [{ results: [{ id: 1 }] }, { results: [{ id: 2 }] }];
        },
      };
    },
  });

  const rows = await client.searchStream("SELECT customer.id FROM customer");

  assert.deepEqual(rows, [{ id: 1 }, { id: 2 }]);
  assert.equal(requests[0].init.headers.get("developer-token"), "test-token");
  assert.equal(
    requests[0].init.headers.get("authorization"),
    "Bearer access-token",
  );
  assert.equal(
    requests[0].init.headers.get("login-customer-id"),
    "1234567890",
  );
});

test("lists directly accessible customers without a manager header", async () => {
  const requests = [];
  const client = createGoogleAdsClient({
    customerId: "1941192637",
    loginCustomerId: "1234567890",
    developerToken: "test-token",
    apiVersion: "v25",
    auth: {
      async getClient() {
        return {
          async getRequestHeaders() {
            return new Headers({ authorization: "Bearer access-token" });
          },
        };
      },
    },
    async fetchImpl(url, init) {
      requests.push({ url, init });
      return {
        ok: true,
        async json() {
          return { resourceNames: ["customers/1234567890"] };
        },
      };
    },
  });

  const resourceNames = await client.listAccessibleCustomers();

  assert.deepEqual(resourceNames, ["customers/1234567890"]);
  assert.equal(requests[0].init.headers.get("login-customer-id"), null);
});
