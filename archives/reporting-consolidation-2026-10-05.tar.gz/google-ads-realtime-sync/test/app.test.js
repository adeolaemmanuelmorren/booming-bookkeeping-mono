import assert from "node:assert/strict";
import test from "node:test";
import { createRequestHandler } from "../src/app.js";

function handler(overrides = {}) {
  return createRequestHandler({
    loadPerformance: async (range) => ({ ...range, rows: [] }),
    listAccessibleCustomers: async () => [],
    maxRangeDays: 366,
    cacheSeconds: 300,
    ...overrides,
  });
}

test("returns staging rows for a requested date range", async () => {
  const response = await handler()({
    method: "GET",
    url: "/v1/google-ads/performance?start_date=2026-09-01&end_date=2026-09-04",
  });

  assert.equal(response.status, 200);
  assert.equal(response.headers["cache-control"], "private, max-age=300");
  assert.deepEqual(JSON.parse(response.body).rows, []);
});

test("rejects an invalid date range before calling Google Ads", async () => {
  let calls = 0;
  const response = await handler({
    async loadPerformance() {
      calls += 1;
      return { rows: [] };
    },
  })({
    method: "GET",
    url: "/v1/google-ads/performance?start_date=nope&end_date=2026-09-04",
  });

  assert.equal(response.status, 400);
  assert.equal(calls, 0);
});
