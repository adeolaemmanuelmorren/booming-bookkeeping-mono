import test from "node:test";
import assert from "node:assert/strict";
import {
  InvalidDateRangeError,
  parseDateRange,
} from "../src/date-window.js";

test("accepts an inclusive calendar date range", () => {
  const range = parseDateRange({
    startDate: "2026-09-01",
    endDate: "2026-09-04",
    maxRangeDays: 366,
  });

  assert.deepEqual(range, {
    startDate: "2026-09-01",
    endDate: "2026-09-04",
  });
});

test("rejects invalid and oversized ranges", () => {
  assert.throws(
    () => parseDateRange({
      startDate: "2026-09-04",
      endDate: "2026-09-01",
      maxRangeDays: 366,
    }),
    InvalidDateRangeError,
  );
  assert.throws(
    () => parseDateRange({
      startDate: "2026-02-30",
      endDate: "2026-03-01",
      maxRangeDays: 366,
    }),
    InvalidDateRangeError,
  );
});
