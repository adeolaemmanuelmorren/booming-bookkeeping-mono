import test from "node:test";
import assert from "node:assert/strict";
import { createHourlyLoader } from "../src/hourly.js";
import { createRequestHandler } from "../src/app.js";

test("hourly endpoint validates dates and leaves the daily endpoint independent", async () => {
  let calls = 0;
  const handle = createRequestHandler({ maxRangeDays: 366, cacheSeconds: 300,
    loadPerformance: async () => ({ daily: true }), loadHourly: async range => { calls++; return range; } });
  assert.equal((await handle({ method: "GET", url: "/v1/google-ads/hourly-performance?start_date=bad&end_date=2026-09-05" })).status, 400);
  assert.equal(calls, 0);
  const response = await handle({ method: "GET", url: "/v1/google-ads/hourly-performance?start_date=2026-09-01&end_date=2026-09-05" });
  assert.equal(response.status, 200);
  assert.equal(JSON.parse(response.body).endDate, "2026-09-05");
  assert.equal(calls, 1);
});

test("hourly loader includes the ending calendar day and shares cached requests", async () => {
  let calls = 0;
  const loader = createHourlyLoader({ cacheSeconds: 300, adsClient: { async searchStream(sql) {
    calls++;
    if (sql.includes("FROM customer")) return [{ customer: { timeZone: "America/Los_Angeles" } }];
    return [{ segments: { date: "2026-11-01", hour: 23 }, customer: { id: "1" },
      campaign: { id: "2", name: "Campaign", advertisingChannelType: "SEARCH" }, adGroup: { id: "3" },
      adGroupAd: { ad: { id: "4" } }, metrics: { costMicros: "1000000", clicks: "1", impressions: "2" } }];
  } } });
  const range = { startDate: "2026-10-31", endDate: "2026-11-01" };
  const [a, b] = await Promise.all([loader(range), loader(range)]);
  assert.equal(a, b);
  assert.equal(a.rows[0].hourPacific, "2026-11-01T23:00");
  assert.equal(a.rows[0].metrics.spend, 1);
  await loader(range);
  assert.deepEqual(a.rows.map(row => row.level), ["campaign", "adset"]);
  assert.equal(calls, 3);
});
