import assert from "node:assert/strict";
import test from "node:test";
import { createPerformanceLoader } from "../src/performance.js";

test("shares and caches matching dashboard requests", async () => {
  let requestCount = 0;
  let nowMs = 1_000;
  const adsClient = {
    async searchStream() {
      requestCount += 1;
      return [];
    },
  };
  const loadPerformance = createPerformanceLoader({
    adsClient,
    cacheSeconds: 300,
    now: () => nowMs,
  });
  const range = { startDate: "2026-09-01", endDate: "2026-09-04" };

  await Promise.all([loadPerformance(range), loadPerformance(range)]);
  await loadPerformance(range);
  assert.equal(requestCount, 2);

  nowMs += 300_001;
  await loadPerformance(range);
  assert.equal(requestCount, 4);
});
