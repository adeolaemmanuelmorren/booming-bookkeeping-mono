import { createGoogleAdsClient } from "./google-ads-client.js";
import { readConfig } from "./config.js";

const client = createGoogleAdsClient(readConfig());
for (const resource of ["campaign", "ad_group", "ad_group_ad"]) {
  const fields = resource === "campaign" ? "" : "ad_group.id,";
  const ad = resource === "ad_group_ad" ? "ad_group_ad.ad.id," : "";
  try {
    const rows = await client.searchStream(`SELECT segments.date, segments.hour, campaign.id,
      ${fields} ${ad} metrics.impressions, metrics.clicks, metrics.cost_micros
      FROM ${resource} WHERE segments.date = '2026-09-04'`);
    console.log(JSON.stringify({ resource, status: "ok", rows: rows.length }));
  } catch (error) {
    console.log(JSON.stringify({ resource, status: "failed", message: error.message,
      validationErrors: error.validationErrors }));
  }
}
