export function createGoogleAdsClient({
  customerId,
  loginCustomerId,
  serviceAccountEmail,
  developerToken,
  apiVersion,
  auth,
  fetchImpl = fetch,
}) {
  async function searchStream(query) {
    const headers = await requestHeaders({
      auth,
      developerToken,
      loginCustomerId,
    });
    headers.set("content-type", "application/json");
    const url = [
      "https://googleads.googleapis.com",
      apiVersion,
      "customers",
      customerId,
      "googleAds:searchStream",
    ].join("/");

    const response = await fetchImpl(url, {
      method: "POST",
      headers,
      body: JSON.stringify({ query }),
    });

    const payload = await response.json();
    if (!response.ok) {
      throw new GoogleAdsApiError(response.status, payload);
    }

    return payload.flatMap((batch) => batch.results ?? []);
  }

  async function listAccessibleCustomers() {
    const headers = await requestHeaders({ auth, developerToken });
    const url = [
      "https://googleads.googleapis.com",
      apiVersion,
      "customers:listAccessibleCustomers",
    ].join("/");
    const response = await fetchImpl(url, { headers });
    const payload = await response.json();

    if (!response.ok) {
      throw new GoogleAdsApiError(response.status, payload);
    }

    return payload.resourceNames ?? [];
  }

  return { searchStream, listAccessibleCustomers };
}

async function requestHeaders({ auth, developerToken, loginCustomerId }) {
  const authClient = await auth.getClient();
  const authHeaders = await authClient.getRequestHeaders();
  const headers = new Headers(authHeaders);
  headers.set("developer-token", developerToken);
  if (loginCustomerId) headers.set("login-customer-id", loginCustomerId);
  return headers;
}

export class GoogleAdsApiError extends Error {
  constructor(status, payload) {
    const response = Array.isArray(payload) ? payload.find(item => item.error) : payload;
    const message = response?.error?.message ?? "Google Ads API request failed.";
    super(`${message} HTTP ${status}.`);
    this.name = "GoogleAdsApiError";
    this.status = status;
    const details = response?.error?.details ?? [];
    this.requestId = details.find(detail => detail.requestId)?.requestId ?? null;
    this.validationErrors = details.flatMap(detail => (detail.errors ?? []).map(error => ({
      code: error.errorCode, message: error.message,
    })));
  }
}
