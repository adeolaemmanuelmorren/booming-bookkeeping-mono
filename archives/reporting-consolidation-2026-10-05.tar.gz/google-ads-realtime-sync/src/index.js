import { createServer } from "node:http";
import { createRequestHandler } from "./app.js";
import { readConfig } from "./config.js";
import { createGoogleAdsClient } from "./google-ads-client.js";
import { createPerformanceLoader } from "./performance.js";
import { createHourlyLoader } from "./hourly.js";

const config = readConfig();
const adsClient = createGoogleAdsClient(config);
const loadPerformance = createPerformanceLoader({
  adsClient,
  cacheSeconds: config.cacheSeconds,
});
const handleRequest = createRequestHandler({
  loadPerformance,
  loadHourly: createHourlyLoader({ adsClient, cacheSeconds: config.cacheSeconds }),
  listAccessibleCustomers: adsClient.listAccessibleCustomers,
  maxRangeDays: config.maxRangeDays,
  cacheSeconds: config.cacheSeconds,
});
const port = Number(process.env.PORT ?? 8080);

const server = createServer(async (request, response) => {
  const result = await handleRequest(request);
  response.writeHead(result.status, result.headers);
  response.end(result.body);
});

server.listen(port, "0.0.0.0", () => {
  console.log(`Google Ads realtime sync listening on port ${port}.`);
});
