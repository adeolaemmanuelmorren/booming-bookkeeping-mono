export function parseDateRange({ startDate, endDate, maxRangeDays }) {
  const start = validDate(startDate, "start_date");
  const end = validDate(endDate, "end_date");
  const rangeDays = daysBetween(start, end) + 1;

  if (rangeDays < 1) {
    throw new InvalidDateRangeError("start_date must be on or before end_date.");
  }
  if (rangeDays > maxRangeDays) {
    throw new InvalidDateRangeError(
      `The requested range cannot exceed ${maxRangeDays} days.`,
    );
  }

  return { startDate: start, endDate: end };
}

export class InvalidDateRangeError extends Error {}

function validDate(value, name) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value ?? "")) {
    throw new InvalidDateRangeError(`${name} must use YYYY-MM-DD.`);
  }

  const parsed = new Date(`${value}T00:00:00.000Z`);
  if (Number.isNaN(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== value) {
    throw new InvalidDateRangeError(`${name} is not a valid calendar date.`);
  }

  return value;
}

function daysBetween(startDate, endDate) {
  const startMs = Date.parse(`${startDate}T00:00:00.000Z`);
  const endMs = Date.parse(`${endDate}T00:00:00.000Z`);
  return Math.round((endMs - startMs) / 86_400_000);
}
