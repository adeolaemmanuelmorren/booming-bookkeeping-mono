import { InvalidDateRangeError, parseDateRange } from "./date-window.js";

export function createRequestHandler({
  loadPerformance,
  loadHourly,
  listAccessibleCustomers,
  maxRangeDays,
  cacheSeconds,
}) {
  return async function handleRequest(request) {
    const url = new URL(request.url, "http://localhost");

    if (request.method === "GET" && url.pathname === "/healthz") {
      return jsonResponse(200, { status: "ok" });
    }

    if (request.method === "POST" && url.pathname === "/accessible-customers") {
      try {
        const resourceNames = await listAccessibleCustomers();
        return jsonResponse(200, { resourceNames });
      } catch (error) {
        console.error("Google Ads access check failed.", error);
        return jsonResponse(500, {
          error: "Google Ads access check failed.",
          requestId: error.requestId ?? null,
        });
      }
    }

    const loader = url.pathname === "/v1/google-ads/performance" ? loadPerformance
      : url.pathname === "/v1/google-ads/hourly-performance" ? loadHourly : null;
    if (request.method !== "GET" || !loader) {
      return jsonResponse(404, { error: "Not found." });
    }

    try {
      const range = parseDateRange({
        startDate: url.searchParams.get("start_date"),
        endDate: url.searchParams.get("end_date"),
        maxRangeDays,
      });
      const result = await loader(range);
      return jsonResponse(200, result, {
        "cache-control": `private, max-age=${cacheSeconds}`,
      });
    } catch (error) {
      if (error instanceof InvalidDateRangeError) {
        return jsonResponse(400, { error: error.message });
      }

      console.error("Google Ads performance request failed.", error);
      return jsonResponse(500, {
        error: "Google Ads performance request failed.",
        requestId: error.requestId ?? null,
      });
    }
  };
}

function jsonResponse(status, body, extraHeaders = {}) {
  return {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      ...extraHeaders,
    },
    body: JSON.stringify(body),
  };
}
