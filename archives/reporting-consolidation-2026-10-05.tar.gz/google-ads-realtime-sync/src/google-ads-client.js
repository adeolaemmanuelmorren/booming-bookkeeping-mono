import { GoogleAuth, Impersonated } from "google-auth-library";
import { createGoogleAdsClient as createRestClient } from "./google-ads-rest-client.js";
export { GoogleAdsApiError } from "./google-ads-rest-client.js";

const GOOGLE_ADS_SCOPE = "https://www.googleapis.com/auth/adwords";

export function createGoogleAdsClient(options) {
  return createRestClient({ ...options,
    auth: options.auth ?? createScopedServiceAccountAuth(options.serviceAccountEmail),
  });
}

function createScopedServiceAccountAuth(serviceAccountEmail) {
  return {
    async getClient() {
      const sourceClient = await new GoogleAuth().getClient();
      return new Impersonated({
        sourceClient,
        targetPrincipal: serviceAccountEmail,
        targetScopes: [GOOGLE_ADS_SCOPE],
        lifetime: 600,
      });
    },
  };
}

