const PMAX_SMART_ID = "pmax_smart";

export function adRows(results, syncedAt) {
  return results.map((result) => ({
    date: result.segments.date,
    account_id: stringValue(result.customer.id),
    account_name: nullableString(result.customer.descriptiveName),
    campaign_id: stringValue(result.campaign.id),
    campaign_name: nullableString(result.campaign.name),
    adset_id: stringValue(result.adGroup.id),
    adset_name: nullableString(result.adGroup.name),
    ad_id: stringValue(result.adGroupAd.ad.id),
    ad_name: nullableString(result.adGroupAd.ad.name),
    landing_page_url: firstUrl(result.adGroupAd.ad),
    ...metrics(result.metrics),
    currency: nullableString(result.customer.currencyCode),
    google_campaign_type: nullableString(
      result.campaign.advertisingChannelType,
    ),
    lowest_grain_type: "ad",
    source_synced_at: syncedAt,
  }));
}

export function campaignRows(results, syncedAt) {
  return results.map((result) => ({
    date: result.segments.date,
    account_id: stringValue(result.customer.id),
    account_name: nullableString(result.customer.descriptiveName),
    campaign_id: stringValue(result.campaign.id),
    campaign_name: nullableString(result.campaign.name),
    adset_id: PMAX_SMART_ID,
    adset_name: PMAX_SMART_ID,
    ad_id: PMAX_SMART_ID,
    ad_name: PMAX_SMART_ID,
    landing_page_url: null,
    ...metrics(result.metrics),
    currency: nullableString(result.customer.currencyCode),
    google_campaign_type: nullableString(
      result.campaign.advertisingChannelType,
    ),
    lowest_grain_type: "campaign",
    source_synced_at: syncedAt,
  }));
}

export function stagingRows(rows) {
  return rows.map((row) => ({
    time: `${row.date}T00:00:00`,
    account_id: row.account_id,
    account_name: row.account_name,
    campaign_id: row.campaign_id,
    campaign_name: row.campaign_name ?? `Google campaign ${row.campaign_id}`,
    adset_id: row.adset_id,
    adset_name: row.adset_name,
    ad_id: row.ad_id,
    ad_name: row.ad_name,
    landing_page_url: row.landing_page_url,
    impressions: Number(row.impressions),
    clicks: Number(row.clicks),
    unique_clicks: Number(row.clicks),
    unique_inline_link_clicks: Number(row.clicks),
    spend: Number(row.cost_micros) / 1_000_000,
    platform_conversions: row.conversions,
    platform_conversion_value: row.conversion_value,
    currency: row.currency ?? "USD",
    google_campaign_type: row.google_campaign_type,
    lowest_grain_type: row.lowest_grain_type,
    _dataform_updated_at: row.source_synced_at,
  }));
}

function metrics(value) {
  return {
    impressions: integerString(value.impressions),
    clicks: integerString(value.clicks),
    cost_micros: integerString(value.costMicros),
    conversions: numberValue(value.conversions),
    conversion_value: numberValue(value.conversionsValue),
  };
}

function firstUrl(ad) {
  return ad.finalUrls?.[0] ?? ad.finalMobileUrls?.[0] ?? null;
}

function stringValue(value) {
  if (value === undefined || value === null || value === "") {
    throw new Error("Google Ads returned a row without a required ID.");
  }
  return String(value);
}

function nullableString(value) {
  if (value === undefined || value === null || value === "") return null;
  return String(value);
}

function integerString(value) {
  if (value === undefined || value === null || value === "") return "0";
  return String(value);
}

function numberValue(value) {
  if (value === undefined || value === null || value === "") return 0;
  return Number(value);
}
