import {
  adPerformanceQuery,
  campaignPerformanceQuery,
} from "./queries.js";
import { adRows, campaignRows, stagingRows } from "./rows.js";

export function createPerformanceLoader({
  adsClient,
  cacheSeconds,
  now = () => Date.now(),
}) {
  const cache = new Map();
  const pendingLoads = new Map();
  const cacheTtlMs = cacheSeconds * 1_000;

  return async function loadPerformance(range) {
    const key = `${range.startDate}:${range.endDate}`;
    const cached = cache.get(key);

    if (cached && cached.expiresAt > now()) return cached.value;
    if (pendingLoads.has(key)) return pendingLoads.get(key);

    const pendingLoad = fetchPerformance({ adsClient, range })
      .then((value) => {
        cache.set(key, { value, expiresAt: now() + cacheTtlMs });
        return value;
      })
      .finally(() => {
        pendingLoads.delete(key);
      });

    pendingLoads.set(key, pendingLoad);
    return pendingLoad;
  };
}

async function fetchPerformance({ adsClient, range }) {
  const [adResults, campaignResults] = await Promise.all([
    adsClient.searchStream(adPerformanceQuery(range)),
    adsClient.searchStream(campaignPerformanceQuery(range)),
  ]);
  const fetchedAt = new Date().toISOString();
  const rows = [
    ...adRows(adResults, fetchedAt),
    ...campaignRows(campaignResults, fetchedAt),
  ];

  return {
    ...range,
    fetchedAt,
    rows: stagingRows(rows),
  };
}
