// Fetch advertiser-local hours. The caller applies its report's hour boundaries.
export function createHourlyLoader({ adsClient, cacheSeconds, now = Date.now }) {
  const cache = new Map();
  const pending = new Map();
  return async function loadHourly(range) {
    const key = `${range.startDate}:${range.endDate}`;
    for (const [key, entry] of cache) if (entry.expiresAt <= now()) cache.delete(key);
    if (cache.has(key)) return cache.get(key).value;
    if (pending.has(key)) return pending.get(key);
    const end = new Date(`${range.endDate}T00:00:00Z`);
    end.setUTCDate(end.getUTCDate() + 1);
    const work = loadGoogleHourly(adsClient, { start: `${range.startDate}T00:00`,
      end: `${end.toISOString().slice(0, 10)}T00:00` }).then(value => {
      if (cache.size >= 100) cache.delete(cache.keys().next().value);
      cache.set(key, { value, expiresAt: now() + cacheSeconds * 1000 });
      return value;
    }).finally(() => pending.delete(key));
    pending.set(key, work);
    return work;
  };
}

export async function loadGoogleHourly(adsClient, selection, now = () => new Date()) {
  const [customer] = await adsClient.searchStream("SELECT customer.id, customer.time_zone FROM customer");
  if (customer?.customer?.timeZone !== "America/Los_Angeles") {
    throw new Error("Google hourly reporting requires a Pacific-time ad account.");
  }
  const startDate = selection.start.slice(0, 10);
  const endDate = selection.end.slice(0, 10);
  if (![startDate, endDate].every((value) => /^\d{4}-\d{2}-\d{2}$/.test(value))) throw new Error("Invalid date range.");
  const rows = [];
  for (const resource of ["campaign", "ad_group"]) {
    const query = `SELECT segments.date, segments.hour, customer.id,
      campaign.id, campaign.name, campaign.advertising_channel_type,
      ${resource === "ad_group" ? "ad_group.id, ad_group.name," : ""}
      metrics.impressions, metrics.clicks, metrics.cost_micros
      FROM ${resource} WHERE segments.date BETWEEN '${startDate}' AND '${endDate}'`;
    const results = await adsClient.searchStream(query);
    for (const result of results) {
      const hour = Number(result.segments.hour);
      if (!Number.isInteger(hour) || hour < 0 || hour > 23) throw new Error("Google returned an invalid hour.");
      const hourPacific = `${result.segments.date}T${String(hour).padStart(2, "0")}:00`;
      if (hourPacific < selection.start || hourPacific >= selection.end) continue;
      rows.push({ source: "google", account: String(result.customer.id), reportDate: result.segments.date,
        hourPacific, level: resource === "campaign" ? "campaign" : "adset", campaignId: String(result.campaign.id),
        adsetId: resource === "ad_group" ? String(result.adGroup.id) : null, adId: null,
        metrics: { campaign_name: result.campaign.name, adset_name: resource === "ad_group" ? result.adGroup.name : null, ad_name: null,
          campaign_type: result.campaign.advertisingChannelType,
          spend: Number(result.metrics.costMicros ?? 0) / 1_000_000,
          impressions: Number(result.metrics.impressions ?? 0), clicks: Number(result.metrics.clicks ?? 0) } });
    }
  }
  return { fetchedAt: now().toISOString(), rows };
}
