const DEFAULTS = {
  customerId: "1941192637",
  apiVersion: "v25",
  timeZone: "America/Los_Angeles",
  serviceAccountEmail:
    "google-ads-reader@able-folio-499722.iam.gserviceaccount.com",
  cacheSeconds: 300,
  maxRangeDays: 366,
};

export function readConfig(env = process.env) {
  const config = {
    customerId: digitsOnly(
      env.GOOGLE_ADS_CUSTOMER_ID ?? DEFAULTS.customerId,
    ),
    loginCustomerId: optionalCustomerId(env.GOOGLE_ADS_LOGIN_CUSTOMER_ID),
    serviceAccountEmail:
      env.GOOGLE_ADS_SERVICE_ACCOUNT_EMAIL ?? DEFAULTS.serviceAccountEmail,
    apiVersion: env.GOOGLE_ADS_API_VERSION ?? DEFAULTS.apiVersion,
    timeZone: env.GOOGLE_ADS_TIME_ZONE ?? DEFAULTS.timeZone,
    cacheSeconds: positiveInteger(
      env.GOOGLE_ADS_CACHE_SECONDS ?? DEFAULTS.cacheSeconds,
      "GOOGLE_ADS_CACHE_SECONDS",
    ),
    maxRangeDays: positiveInteger(
      env.GOOGLE_ADS_MAX_RANGE_DAYS ?? DEFAULTS.maxRangeDays,
      "GOOGLE_ADS_MAX_RANGE_DAYS",
    ),
    developerToken: env.GOOGLE_ADS_DEVELOPER_TOKEN,
  };

  if (!config.developerToken) {
    throw new Error("GOOGLE_ADS_DEVELOPER_TOKEN is required.");
  }
  if (!config.serviceAccountEmail) {
    throw new Error("GOOGLE_ADS_SERVICE_ACCOUNT_EMAIL is required.");
  }

  return config;
}

function optionalCustomerId(value) {
  if (!value) return null;
  return digitsOnly(value);
}

function digitsOnly(value) {
  const normalized = String(value).replaceAll("-", "");
  if (!/^\d{10}$/.test(normalized)) {
    throw new Error("GOOGLE_ADS_CUSTOMER_ID must contain 10 digits.");
  }
  return normalized;
}

function positiveInteger(value, name) {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 1) {
    throw new Error(`${name} must be a positive integer.`);
  }
  return parsed;
}
