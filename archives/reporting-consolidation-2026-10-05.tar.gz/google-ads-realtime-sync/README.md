# Google Ads realtime sync

This private Cloud Run service reads Google Ads reporting data when the
dashboard requests a date range. It returns the same columns as
`stg_google_ads`. It does not run on a schedule and does not write to BigQuery.

The service makes two Google Ads API operations per run:

- ad-level metrics for non-Performance Max and non-Smart campaigns
- campaign-level metrics for Performance Max and Smart campaigns

It does not use a downloaded service-account key. Cloud Run supplies the
runtime identity. The identity mints a short-lived token scoped only for the
Google Ads API. Secret Manager supplies the developer token.

## Google Ads access still required

Add this email as a read-only user on the manager account linked above Google
Ads customer `194-119-2637`:

`google-ads-reader@able-folio-499722.iam.gserviceaccount.com`

An administrator of that manager must perform this account-level step. Set
`GOOGLE_ADS_LOGIN_CUSTOMER_ID` to the manager customer ID without hyphens.

## Endpoint

`GET /v1/google-ads/performance?start_date=YYYY-MM-DD&end_date=YYYY-MM-DD`

Both dates are inclusive. Responses use a five-minute in-memory cache by
default. A cache miss uses two Google Ads API operations.

## Runtime configuration

See `.env.example`. The deployed service uses API version `v25` and returns
Google Ads reporting dates in the account's Pacific time zone.
