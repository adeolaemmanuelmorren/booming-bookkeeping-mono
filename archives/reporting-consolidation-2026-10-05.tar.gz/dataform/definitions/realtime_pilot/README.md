# Separate realtime Dataform test

All definitions in this folder write only to
`able-folio-499722.bill_reports_sql_pilot_20260921`.
They are disabled unless compilation variable `realtime_pilot=true` is set.
The dedicated action tag is `realtime_pilot`. No production schedule or dashboard
routing is changed by adding this folder.

## Execution order

1. `inputs/` combines frozen hourly sources with fetched source replacements.
   Complete contact membership and invoice-line scopes replace their prior rows.
   Ad snapshots replace the fetched reporting day.
2. `reference/` builds the independent full SQL comparison from frozen source inputs.
   It also prepares the shared staging, catalog, and customer-fact lookup tables used
   by this first test. This full reference rebuild is test-only work.
3. `incremental/df_rt_keyed_*` selects browser and customer/payment changes using
   incoming source keys and recalculates the corresponding identity events.
4. `incremental/df_rt_identity_events` replaces the affected hourly identity events.
5. `incremental/df_rt_identity_scope` expands affected identifiers through old and
   current graph edges and selects their historical events.
6. `incremental/df_rt_key_scoped_identities` resolves the selected identity groups.
7. `incremental/df_rt_identity_merge` retains unaffected profiles and records the
   affected old/new profile IDs for attribution.
8. `incremental/df_rt_key_scoped_mart_*` recalculates affected attribution;
   `df_rt_key_incremental_mart_*` restores unaffected hourly rows.
9. `reporting/` aggregates the resulting reporting tables.
10. `validation/df_rt_validation` checks all five reporting outputs against the full
   reference, including duplicate-row multiplicity. Any mismatch fails the action.
11. `publication/df_rt_publication` updates only the pilot publication marker in a
    transaction, after successful validation.

Dependencies are explicit in each SQLX config. BigQuery executes all transformations;
Dataform controls ordering and blocks dependent actions after failure. Python under
`validation/realtime_pilot/` only generates/uploads definitions and invokes the test.
No local script executes the report calculations during this Dataform run.

## Input contract and limits

This run reuses the already fetched September 21 batch and the coherent hourly-only
replay from the warehouse pilot. It does not fetch providers, advance production
cursors, or prove a recurring production refresh SLA. The pilot dataset and its input snapshots are temporary; some ad snapshots expire
after two days and the dataset default is seven days; this frozen test must be refreshed before later reruns.

The typed source deltas and ad snapshots were staged by the earlier fetch
experiment. Hourly/source replacement now runs in this Dataform graph. This first
port still prepares full shared lookup tables in its reference branch. Making a recurring production workflow requires a durable input batch
manifest, source version coverage, overlap control, and hourly-generation handover.
The dedicated folder is deliberately named `realtime_pilot` until that work is done.

The full reference branch must not be mistaken for the intended fast production
path. Its purpose here is to test that moving orchestration into Dataform preserves
all results. Production is not switched by this test.

## Local compilation

Enable the test explicitly:

```sh
dataform compile dataform --vars=realtime_pilot=true --json
```

Normal compilation leaves every action in this folder disabled:

```sh
dataform compile dataform --json
```

Execution details and captured evidence live in `dataform/validation/realtime_pilot/`.
